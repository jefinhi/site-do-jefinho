'use client';

import QRCode from 'qrcode';

export function getWhatsAppUrl(phoneRaw: string, message: string): string {
  // Strip non-digits
  const cleanPhone = phoneRaw.replace(/\D/g, '');
  // ensure country code 55 (Brazil)
  const fullPhone = cleanPhone.startsWith('55') ? cleanPhone : `55${cleanPhone}`;
  return `https://wa.me/${fullPhone}?text=${encodeURIComponent(message)}`;
}

export async function generateWhatsAppQrCode(url: string): Promise<string> {
  try {
    const dataUrl = await QRCode.toDataURL(url, {
      width: 400,
      margin: 1.5,
      color: {
        dark: '#051b11',
        light: '#ffffff',
      },
      errorCorrectionLevel: 'H',
    });
    return dataUrl;
  } catch (error) {
    console.error('Error generating QR code:', error);
    return '';
  }
}

export interface LeadClickEvent {
  id: string;
  timestamp: string;
  source: string;
  projectTitle?: string;
  phone: string;
}

const STORAGE_LEADS_KEY = 'jr_portfolio_lead_clicks';
const STORAGE_CONFIG_KEY = 'jr_portfolio_site_config';
const STORAGE_PROJECTS_KEY = 'jr_portfolio_custom_projects';

export function trackLeadClick(source: string, projectTitle?: string): void {
  if (typeof window === 'undefined') return;
  try {
    const existing = JSON.parse(localStorage.getItem(STORAGE_LEADS_KEY) || '[]') as LeadClickEvent[];
    const newEvent: LeadClickEvent = {
      id: Math.random().toString(36).substring(2, 9),
      timestamp: new Date().toISOString(),
      source,
      projectTitle,
      phone: '22981728574',
    };
    existing.unshift(newEvent);
    // keep last 100
    localStorage.setItem(STORAGE_LEADS_KEY, JSON.stringify(existing.slice(0, 100)));
  } catch (err) {
    console.warn('Could not store lead event:', err);
  }
}

export function getLeadClicks(): LeadClickEvent[] {
  if (typeof window === 'undefined') return [];
  try {
    return JSON.parse(localStorage.getItem(STORAGE_LEADS_KEY) || '[]');
  } catch {
    return [];
  }
}
