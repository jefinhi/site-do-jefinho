export interface Project {
  id: string;
  title: string;
  subtitle: string;
  category: 'confeitaria' | 'padaria' | 'beleza' | 'construcao' | 'petshop' | 'todos';
  categoryLabel: string;
  description: string;
  url: string;
  image: string;
  tags: string[];
  features: string[];
  deliverables: string[];
  client: string;
  reviewSnippet: string;
  viewsEstimate: string;
  conversionRate: string;
  status: 'online' | 'em_atualizacao';
}

export interface Testimonial {
  id: string;
  name: string;
  role: string;
  company: string;
  avatar: string;
  stars: number;
  text: string;
  verified: boolean;
  date?: string;
  websiteUrl?: string;
  likes?: number;
}

export interface Service {
  id: string;
  title: string;
  description: string;
  iconName: 'Globe' | 'ShoppingBag' | 'Target' | 'Wrench' | 'Cloud' | 'Headphones';
  badge: string;
  points: string[];
}



export interface SiteConfig {
  developerName: string;
  brandName: string;
  phoneRaw: string;
  phoneFormatted: string;
  whatsappMessageDefault: string;
  instagram: string;
  facebook: string;
  youtube: string;
  location: string;
}

export const INITIAL_CONFIG: SiteConfig = {
  developerName: 'Jeferson Ribeiro',
  brandName: 'CRIADOR DE SITES',
  phoneRaw: '22981728574',
  phoneFormatted: '(22) 98172-8574',
  whatsappMessageDefault: 'Olá Jeferson! Vi seu portfólio e gostaria de um orçamento para criar o site do meu negócio.',
  instagram: 'https://instagram.com/jefersonribeiro.sites',
  facebook: 'https://facebook.com',
  youtube: 'https://youtube.com',
  location: 'Rio de Janeiro / Atendimento em Todo o Brasil',
};

export const INITIAL_PROJECTS: Project[] = [
  {
    id: 'delicias-da-tati',
    title: 'Delícias da Tati',
    subtitle: 'Confeitaria e Salgados',
    category: 'confeitaria',
    categoryLabel: 'Confeitaria & Salgados',
    description:
      'Site moderno e apetitoso para confeitaria artesanal, com vitrine de bolos personalizados, cardápio digital de salgados gourmet e botão de pedidos direto no WhatsApp.',
    url: 'https://del-cias-da-tati.vercel.app/',
    image: '/images/mockup_delicias_tati.jpg',
    tags: ['Cardápio Digital', 'Pedidos no WhatsApp', 'Design Responsivo', 'SEO Local'],
    features: [
      'Vitrine interativa de produtos com fotos em alta resolução',
      'Botão de pedido direto para o WhatsApp com item pré-selecionado',
      'Layout responsivo otimizado para celular (Instagram e Facebook)',
      'Carregamento ultra rápido (menos de 1 segundo)',
    ],
    deliverables: ['Página de Vendas', 'Integração WhatsApp', 'Hospedagem Vercel', 'Domínio Otimizado'],
    client: 'Tati Confeitaria',
    reviewSnippet: 'O site aumentou muito nossos pedidos de encomendas de fim de semana!',
    viewsEstimate: '+1.800 acessos/mês',
    conversionRate: 'Alta conversão via WhatsApp',
    status: 'online',
  },
  {
    id: 'padaria-artesanal',
    title: 'Minha Padaria',
    subtitle: 'Padaria e Cafeteria Artesanal',
    category: 'padaria',
    categoryLabel: 'Padaria & Cafeteria',
    description:
      'Página charmosa e ágil para padaria e confeitaria de bairro com pães de fermentação natural, horários de fornadas quentinhas e pedidos para retirada e delivery.',
    url: 'https://padaria-nu-virid.vercel.app/',
    image: '/images/mockup_padaria.jpg',
    tags: ['Delivery Fácil', 'Tabela de Pães e Fornadas', 'Localização Integrada', 'Design Aconchegante'],
    features: [
      'Aviso de pão quentinho e cardápio de café matinal',
      'Integração com Google Maps para clientes encontrarem a loja facilmente',
      'Botão flutuante de atendimento WhatsApp',
      'Otimizado para anúncios no Facebook e Instagram Ads',
    ],
    deliverables: ['Cardápio Online', 'Google Maps Local', 'Design Mobile First', 'Certificado SSL'],
    client: 'Padaria Artesanal Nu',
    reviewSnippet: 'Nossos clientes adoram consultar o cardápio pelo celular antes de vir à loja.',
    viewsEstimate: '+2.400 acessos/mês',
    conversionRate: 'Mais de 120 contatos no WhatsApp',
    status: 'online',
  },
  {
    id: 'petshop-care',
    title: 'PetShop',
    subtitle: 'Tudo para o seu pet',
    category: 'petshop',
    categoryLabel: 'Pet & Veterinária',
    description:
      'Ambiente alegre e dinâmico para clínica veterinária, banho e tosa e boutique pet, com agendamento direto de horários e exibição de planos de cuidados.',
    url: 'https://inquisitive-kashata-251471.netlify.app/',
    image: '/images/mockup_petshop.jpg',
    tags: ['Agendamento Banho & Tosa', 'Clínica Veterinária', 'Atendimento Rápido', 'Design Amigável'],
    features: [
      'Agendamento simplificado com seleção de porte do pet',
      'Apresentação de serviços clínicos e vacinas preventivas',
      'Galeria de pets bem cuidados e depoimentos de tutores',
      'Chamada para ação clara em todos os blocos',
    ],
    deliverables: ['Landing Page Pet', 'Módulo de Agendamento', 'Integração Netlify', 'Otimização Mobile'],
    client: 'PetShop & Clínica',
    reviewSnippet: 'A agenda de banho e tosa agora fica lotada a semana inteira!',
    viewsEstimate: '+1.500 acessos/mês',
    conversionRate: 'Agendamentos automáticos via WhatsApp',
    status: 'online',
  },
  {
    id: 'salao-de-beleza',
    title: 'Salão de Beleza',
    subtitle: 'Beleza e autoestima',
    category: 'beleza',
    categoryLabel: 'Salão & Estética',
    description:
      'Página elegante e sofisticada para espaço de beleza e estética feminina, valorizando transformações, cortes, mechas, estética facial e agendamento VIP.',
    url: 'https://sites.google.com/view/bellaes/sal%C3%A3o-de-beleza',
    image: '/images/mockup_salao_beleza.jpg',
    tags: ['Estética & Cabelos', 'Galeria Antes & Depois', 'Agendamento VIP', 'Design Premium'],
    features: [
      'Visual dark chic sofisticado que transmite alto padrão',
      'Apresentação de serviços: corte, mechas, hidratação e maquiagem',
      'Botão de agendamento personalizado por profissional',
      'Depoimentos e fotos de resultados reais',
    ],
    deliverables: ['Portal Institucional', 'Catálogo de Serviços', 'Link Direto WhatsApp', 'Presença Online'],
    client: 'Bella & Estilo Salão',
    reviewSnippet: 'Transmitiu exatamente a elegância que minhas clientes merecem!',
    viewsEstimate: '+1.200 acessos/mês',
    conversionRate: 'Captação constante de novas clientes',
    status: 'online',
  },
  {
    id: 'material-construcao',
    title: 'Material de Construção',
    subtitle: 'Tudo para sua obra',
    category: 'construcao',
    categoryLabel: 'Construção & Reformas',
    description:
      'Catálogo online robusto para loja de materiais de construção, cimento, ferragens, pisos e tintas, facilitando orçamentos rápidos para pedreiros e mestres de obras.',
    url: 'https://sites.google.com/view/casafor/mariais-de-contru%C3%A7%C3%A3o',
    image: '/images/mockup_casa_forte.jpg',
    tags: ['Cotação Rápida', 'Materiais Básicos ao Acabamento', 'Entrega Rápida na Região', 'B2B & B2C'],
    features: [
      'Solicitação de cotação de lista de materiais com 1 clique',
      'Categorias organizadas: alvenaria, hidráulica, elétrica e acabamento',
      'Destaque para frete grátis ou entrega no mesmo dia no bairro',
      'Contato direto com o televendas no WhatsApp',
    ],
    deliverables: ['Catálogo Digital', 'Canal de Orçamentos', 'Otimização Local no Google', 'Google Sites Integrado'],
    client: 'Casa Forte Materiais',
    reviewSnippet: 'Orçamentos que antes demoravam horas agora chegam prontos no nosso WhatsApp!',
    viewsEstimate: '+3.100 acessos/mês',
    conversionRate: 'Mais de 200 orçamentos/mês',
    status: 'online',
  },
];

export const SERVICES_DATA: Service[] = [
  {
    id: 'institucional',
    title: 'Site Institucional',
    description: 'Apresente sua empresa com profissionalismo.',
    iconName: 'Globe',
    badge: 'Mais pedido',
    points: [
      'Credibilidade imediata para novos clientes',
      'Seu endereço, horário e história no Google',
      'Totalmente adaptado para celulares e tablets',
    ],
  },
  {
    id: 'loja',
    title: 'Loja Virtual',
    description: 'Venda seus produtos 24h por dia.',
    iconName: 'ShoppingBag',
    badge: 'Vendas 24h',
    points: [
      'Catálogo completo com fotos e preços',
      'Recebimento por PIX, Cartão e Boleto',
      'Controle simples de pedidos e entregas',
    ],
  },
  {
    id: 'landing',
    title: 'Landing Pages',
    description: 'Capture mais leads e aumente suas vendas.',
    iconName: 'Target',
    badge: 'Alta Conversão',
    points: [
      'Estrutura persuasiva focada em vendas',
      'Ideal para anúncios no Facebook, Instagram e Google',
      'Botão direto para o seu WhatsApp',
    ],
  },
  {
    id: 'manutencao',
    title: 'Manutenção',
    description: 'Seu site sempre atualizado e seguro.',
    iconName: 'Wrench',
    badge: 'Segurança Total',
    points: [
      'Atualizações regulares de segurança',
      'Alterações rápidas de textos, fotos e promoções',
      'Backups automáticos preventivos',
    ],
  },
  {
    id: 'hospedagem',
    title: 'Hospedagem',
    description: 'Alta performance e estabilidade.',
    iconName: 'Cloud',
    badge: 'Super Rápido',
    points: [
      'Servidores em nuvem de última geração',
      'Certificado de Segurança SSL Grátis incluso',
      'Carregamento instantâneo sem travamentos',
    ],
  },
  {
    id: 'suporte',
    title: 'Suporte',
    description: 'Estou sempre por perto para te ajudar.',
    iconName: 'Headphones',
    badge: 'Atendimento Humanizado',
    points: [
      'Contato direto pelo WhatsApp (sem robôs)',
      'Resolução ágil de dúvidas e ajustes',
      'Treinamento simples para você usar seu site',
    ],
  },
];

export const TESTIMONIALS_DATA: Testimonial[] = [
  {
    id: 'ana-paula',
    name: 'Ana Paula',
    role: 'Proprietária',
    company: 'Delícias da Tati',
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&auto=format&fit=crop&q=80',
    stars: 5,
    text: '“O site ficou incrível! Superou todas as minhas expectativas. Meus clientes adoram o cardápio e os pedidos aumentaram muito. Recomendo demais!”',
    verified: true,
    date: 'Há 2 semanas',
    websiteUrl: 'https://del-cias-da-tati.vercel.app/',
    likes: 12,
  },
  {
    id: 'carlos-henrique',
    name: 'Carlos Henrique',
    role: 'Diretor Comercial',
    company: 'Casa Forte Materiais',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    stars: 5,
    text: '“Profissional atencioso, rápido e com um trabalho de excelente qualidade! As cotações de materiais de construção chegam organizadas no WhatsApp.”',
    verified: true,
    date: 'Há 1 mês',
    websiteUrl: 'https://sites.google.com/view/casafor/mariais-de-contru%C3%A7%C3%A3o',
    likes: 9,
  },
  {
    id: 'juliana-souza',
    name: 'Juliana Souza',
    role: 'Gerente',
    company: 'Padaria Artesanal Nu',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    stars: 5,
    text: '“Meu delivery agora recebe muito mais pedidos. O site é lindo, rápido e super funcional no celular! Todo mundo elogia.”',
    verified: true,
    date: 'Há 1 mês',
    websiteUrl: 'https://padaria-nu-virid.vercel.app/',
    likes: 15,
  },
  {
    id: 'roberto-silva',
    name: 'Roberto Silva',
    role: 'Médico Veterinário',
    company: 'PetShop & Clínica',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
    stars: 5,
    text: '“Atendimento top e suporte sempre que precisei. Os agendamentos de banho e tosa dobraram depois do site no ar. Indico de olhos fechados!”',
    verified: true,
    date: 'Há 2 meses',
    websiteUrl: 'https://inquisitive-kashata-251471.netlify.app/',
    likes: 18,
  },
];
