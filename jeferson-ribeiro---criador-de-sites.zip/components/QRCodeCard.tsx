'use client';

import { useEffect, useState } from 'react';
import { generateWhatsAppQrCode, getWhatsAppUrl, trackLeadClick } from '@/lib/whatsapp-utils';
import { MessageCircle, Download, Check, Copy, ExternalLink, Sparkles } from 'lucide-react';

interface QRCodeCardProps {
  phoneRaw: string;
  phoneFormatted: string;
  message?: string;
  variant?: 'hero' | 'footer' | 'standalone';
  label?: string;
  sublabel?: string;
  showDownload?: boolean;
}

export function QRCodeCard({
  phoneRaw,
  phoneFormatted,
  message = 'Olá Jeferson! Vi seu QR Code e gostaria de um orçamento para meu site.',
  variant = 'hero',
  label = 'Escaneie o QR Code e fale comigo!',
  sublabel = 'Aponte a câmera do seu celular para abrir o WhatsApp na hora',
  showDownload = false,
}: QRCodeCardProps) {
  const [qrSrc, setQrSrc] = useState<string>('');
  const [copied, setCopied] = useState(false);

  const whatsappLink = getWhatsAppUrl(phoneRaw, message);

  useEffect(() => {
    generateWhatsAppQrCode(whatsappLink).then((url) => {
      if (url) setQrSrc(url);
    });
  }, [whatsappLink]);

  const handleCopyPhone = () => {
    navigator.clipboard.writeText(phoneFormatted || phoneRaw);
    setCopied(true);
    trackLeadClick('copy_phone');
    setTimeout(() => setCopied(false), 2500);
  };

  const handleDownloadQr = () => {
    if (!qrSrc) return;
    const a = document.createElement('a');
    a.href = qrSrc;
    a.download = `qrcode-whatsapp-jeferson-ribeiro-${phoneRaw}.png`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  if (variant === 'hero') {
    return (
      <div className="flex flex-col items-start sm:flex-row sm:items-center gap-3 bg-[#0d1813]/90 border border-[#22c55e]/30 p-3.5 rounded-2xl shadow-[0_0_25px_rgba(34,197,94,0.12)] backdrop-blur-sm">
        {/* QR Code Container */}
        <div className="relative group">
          <div className="w-20 h-20 sm:w-24 sm:h-24 bg-white p-1.5 rounded-xl flex items-center justify-center shadow-inner overflow-hidden">
            {qrSrc ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img
                src={qrSrc}
                alt="QR Code WhatsApp Jeferson Ribeiro"
                className="w-full h-full object-contain"
              />
            ) : (
              <div className="w-full h-full bg-slate-100 animate-pulse rounded" />
            )}
            {/* Center mini WhatsApp icon */}
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
              <div className="bg-[#22c55e] text-white p-1 rounded-full shadow-md">
                <MessageCircle className="w-3.5 h-3.5 fill-white text-white" />
              </div>
            </div>
          </div>
          <a
            href={whatsappLink}
            target="_blank"
            rel="noopener noreferrer"
            onClick={() => trackLeadClick('hero_qr_click')}
            className="absolute inset-0 z-10 opacity-0"
            title="Abrir no WhatsApp"
          >
            Abrir
          </a>
        </div>

        {/* Text Annotation with decorative indicator */}
        <div className="flex flex-col">
          <div className="flex items-center gap-1.5 text-xs text-slate-300 font-medium font-sans">
            <span className="text-[#22c55e] animate-bounce">⚡</span>
            <span>{label}</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-0.5 max-w-[200px] leading-tight">
            Aponte a câmera e fale direto com o criador dos sites.
          </p>
          <div className="flex items-center gap-2 mt-2">
            <a
              href={whatsappLink}
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => trackLeadClick('hero_qr_text_click')}
              className="inline-flex items-center gap-1 text-[11px] text-[#22c55e] font-semibold hover:underline"
            >
              <span>Abrir WhatsApp</span>
              <ExternalLink className="w-3 h-3" />
            </a>
            <span className="text-slate-600">•</span>
            <button
              onClick={handleCopyPhone}
              className="text-[11px] text-slate-400 hover:text-white transition flex items-center gap-1 cursor-pointer"
            >
              {copied ? (
                <>
                  <Check className="w-3 h-3 text-[#22c55e]" />
                  <span className="text-[#22c55e]">Copiado!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3 h-3" />
                  <span>{phoneFormatted}</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Large CTA / Footer variant
  return (
    <div className="relative bg-gradient-to-b from-[#0f241a] to-[#0a1510] border-2 border-[#22c55e]/50 p-6 sm:p-8 rounded-3xl shadow-[0_0_40px_rgba(34,197,94,0.2)] text-center max-w-sm mx-auto">
      {/* Curved script text indicator */}
      <div className="absolute -top-5 -right-3 sm:-right-6 rotate-6 bg-[#22c55e] text-black text-xs font-black px-3.5 py-1 rounded-full shadow-lg flex items-center gap-1.5">
        <Sparkles className="w-3.5 h-3.5" />
        <span>Aponte a câmera e fale comigo!</span>
      </div>

      <div className="relative inline-block mx-auto mb-5 p-3 bg-white rounded-2xl shadow-xl">
        <div className="w-44 h-44 sm:w-52 sm:h-52 relative flex items-center justify-center">
          {qrSrc ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={qrSrc}
              alt="QR Code WhatsApp Jeferson Ribeiro (22) 98172-8574"
              className="w-full h-full object-contain"
            />
          ) : (
            <div className="w-full h-full bg-slate-100 animate-pulse rounded-xl" />
          )}

          {/* Central Logo Stamp */}
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="w-10 h-10 bg-[#22c55e] border-2 border-white rounded-full flex items-center justify-center shadow-lg">
              <MessageCircle className="w-5 h-5 text-white fill-white" />
            </div>
          </div>
        </div>
      </div>

      <p className="text-xs text-slate-300 font-medium mb-3">{sublabel}</p>

      {/* Main Direct Phone Button */}
      <a
        href={whatsappLink}
        target="_blank"
        rel="noopener noreferrer"
        onClick={() => trackLeadClick('footer_big_qr_cta')}
        className="w-full flex items-center justify-center gap-2.5 bg-[#22c55e] hover:bg-[#20b857] text-black font-extrabold text-lg sm:text-xl py-3.5 px-6 rounded-2xl shadow-[0_4px_20px_rgba(34,197,94,0.4)] transition-all hover:scale-[1.02] active:scale-[0.98]"
      >
        <MessageCircle className="w-6 h-6 fill-black" />
        <span>{phoneFormatted}</span>
      </a>

      {/* Action Buttons: Copy & Download */}
      <div className="flex items-center justify-center gap-3 mt-4 pt-4 border-t border-slate-800">
        <button
          onClick={handleCopyPhone}
          className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-[#22c55e] transition py-1.5 px-3 rounded-lg bg-slate-900/60 border border-slate-800"
        >
          {copied ? <Check className="w-3.5 h-3.5 text-[#22c55e]" /> : <Copy className="w-3.5 h-3.5" />}
          <span>{copied ? 'Número Copiado!' : 'Copiar Número'}</span>
        </button>

        {showDownload && (
          <button
            onClick={handleDownloadQr}
            className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-[#22c55e] transition py-1.5 px-3 rounded-lg bg-slate-900/60 border border-slate-800"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Baixar Imagem QR</span>
          </button>
        )}
      </div>
    </div>
  );
}
