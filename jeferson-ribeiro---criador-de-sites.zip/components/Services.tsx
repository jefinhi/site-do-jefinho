'use client';

import { SERVICES_DATA, Service } from '@/lib/portfolio-data';
import {
  Globe,
  ShoppingBag,
  Target,
  Wrench,
  Cloud,
  Headphones,
  ArrowRight,
  CheckCircle2,
} from 'lucide-react';
import { getWhatsAppUrl, trackLeadClick } from '@/lib/whatsapp-utils';

const iconMap = {
  Globe,
  ShoppingBag,
  Target,
  Wrench,
  Cloud,
  Headphones,
};

interface ServicesProps {
  phoneRaw: string;
}

export function Services({ phoneRaw }: ServicesProps) {
  return (
    <section
      id="servicos"
      className="relative py-20 sm:py-28 bg-[#070e0a] border-t border-b border-[#22c55e]/15 overflow-hidden"
    >
      {/* Glow highlight */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[400px] bg-[#22c55e]/5 blur-[160px] rounded-full pointer-events-none" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 text-xs uppercase tracking-widest text-[#22c55e] font-bold mb-3">
            <span className="h-px w-8 bg-[#22c55e]" />
            <span>NOSSOS SERVIÇOS</span>
            <span className="h-px w-8 bg-[#22c55e]" />
          </div>

          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black text-white tracking-tight mb-4">
            Soluções completas para o <span className="text-[#22c55e]">seu negócio</span>
          </h2>

          <p className="text-base sm:text-lg text-slate-300 leading-relaxed">
            Do site simples ao projeto mais completo, eu cuido de tudo para você ter uma presença online profissional e eficiente.
          </p>
        </div>

        {/* 6 Services Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {SERVICES_DATA.map((service) => {
            const IconComponent = iconMap[service.iconName] || Globe;
            const whatsappLink = getWhatsAppUrl(
              phoneRaw,
              `Olá Jeferson! Gostaria de saber mais sobre o serviço de ${service.title} para minha empresa.`
            );

            return (
              <div
                key={service.id}
                className="group relative bg-[#0b1711] hover:bg-[#0f2118] border border-[#22c55e]/25 hover:border-[#22c55e]/70 p-7 rounded-2xl transition-all duration-300 shadow-lg hover:shadow-[0_10px_30px_rgba(34,197,94,0.15)] flex flex-col justify-between"
              >
                <div>
                  {/* Top Row: Icon and Badge */}
                  <div className="flex items-center justify-between mb-5">
                    <div className="w-14 h-14 rounded-xl bg-[#132d20] border border-[#22c55e]/40 flex items-center justify-center text-[#22c55e] group-hover:scale-110 group-hover:bg-[#22c55e] group-hover:text-black transition-all duration-300 shadow-md">
                      <IconComponent className="w-7 h-7" />
                    </div>
                    <span className="text-[11px] font-bold text-[#4ade80] bg-[#163826] border border-[#22c55e]/30 px-2.5 py-0.5 rounded-full">
                      {service.badge}
                    </span>
                  </div>

                  {/* Title & Description */}
                  <h3 className="text-xl font-bold text-white mb-2 group-hover:text-[#4ade80] transition-colors">
                    {service.title}
                  </h3>
                  <p className="text-sm text-slate-300 leading-relaxed mb-5">
                    {service.description}
                  </p>

                  {/* Bullet points */}
                  <ul className="space-y-2 mb-6 text-xs text-slate-400">
                    {service.points.map((pt, idx) => (
                      <li key={idx} className="flex items-start gap-2">
                        <CheckCircle2 className="w-3.5 h-3.5 text-[#22c55e] shrink-0 mt-0.5" />
                        <span>{pt}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Card Action Link */}
                <a
                  href={whatsappLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={() => trackLeadClick(`service_${service.id}`)}
                  className="inline-flex items-center justify-between w-full pt-4 border-t border-slate-800/80 text-xs font-bold text-[#22c55e] group-hover:text-white transition-colors"
                >
                  <span>Solicitar este serviço</span>
                  <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                </a>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
