'use client';

import { useState, useEffect } from 'react';
import { BrandLogo } from './BrandLogo';
import { MessageCircle, Menu, X, Settings, ShieldCheck, PhoneCall, Star } from 'lucide-react';
import { getWhatsAppUrl, trackLeadClick } from '@/lib/whatsapp-utils';

interface NavbarProps {
  phoneRaw: string;
  phoneFormatted: string;
  onOpenAdmin: () => void;
  onOpenReviewModal?: () => void;
}

export function Navbar({ phoneRaw, phoneFormatted, onOpenAdmin, onOpenReviewModal }: NavbarProps) {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const whatsappUrl = getWhatsAppUrl(
    phoneRaw,
    'Olá Jeferson! Vi seu portfólio e gostaria de um orçamento para criar o site do meu negócio.'
  );

  const navLinks = [
    { label: 'Início', href: '#inicio' },
    { label: 'Serviços', href: '#servicos' },
    { label: 'Portfólio', href: '#portfolio' },
    { label: 'Depoimentos', href: '#depoimentos' },
    { label: 'Contato', href: '#contato' },
  ];

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    setMobileMenuOpen(false);
    const target = document.querySelector(href);
    if (target) {
      target.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? 'bg-[#070e0a]/95 backdrop-blur-md border-b border-[#22c55e]/20 py-2.5 shadow-lg shadow-black/40'
          : 'bg-gradient-to-b from-[#070e0a]/90 via-[#070e0a]/60 to-transparent py-4'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <a
            href="#inicio"
            onClick={(e) => handleNavClick(e, '#inicio')}
            className="group transition transform active:scale-95"
          >
            <BrandLogo size="md" />
          </a>

          {/* Desktop Navigation Links */}
          <nav className="hidden md:flex items-center gap-1 bg-[#0f1d16]/70 border border-[#22c55e]/20 px-4 py-1.5 rounded-full backdrop-blur-sm shadow-inner">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={(e) => handleNavClick(e, link.href)}
                className="px-3.5 py-1.5 text-sm font-medium text-slate-200 hover:text-[#22c55e] hover:bg-[#22c55e]/10 rounded-full transition-all duration-200"
              >
                {link.label}
              </a>
            ))}
          </nav>

          {/* Actions & WhatsApp CTA */}
          <div className="hidden sm:flex items-center gap-2.5">
            {/* Avaliar button for existing clients */}
            {onOpenReviewModal && (
              <button
                onClick={onOpenReviewModal}
                title="Deixar avaliação do seu site"
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#163323] hover:bg-[#1f4731] border border-[#22c55e]/40 text-[#4ade80] hover:text-white text-xs font-semibold transition"
              >
                <Star className="w-3.5 h-3.5 fill-[#fbbf24] text-[#fbbf24]" />
                <span>Avaliar Meu Site</span>
              </button>
            )}

            {/* Admin Dashboard trigger */}
            <button
              onClick={onOpenAdmin}
              title="Painel Administrativo de Gestão"
              className="p-2 text-slate-400 hover:text-[#22c55e] hover:bg-[#22c55e]/10 rounded-xl transition border border-slate-800"
            >
              <Settings className="w-4 h-4" />
            </button>

            {/* Main CTA Button: Fale Comigo */}
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => trackLeadClick('navbar_cta')}
              className="group relative inline-flex items-center gap-2 bg-[#22c55e] hover:bg-[#20b857] text-black font-extrabold text-sm px-5 py-2.5 rounded-full shadow-[0_0_18px_rgba(34,197,94,0.45)] transition-all hover:scale-105 active:scale-95"
            >
              <MessageCircle className="w-4 h-4 fill-black text-black group-hover:rotate-12 transition-transform" />
              <span>Fale Comigo</span>
            </a>
          </div>

          {/* Mobile Menu Button */}
          <div className="flex sm:hidden items-center gap-2">
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => trackLeadClick('navbar_mobile_whatsapp')}
              className="p-2 bg-[#22c55e] text-black rounded-full shadow-md"
            >
              <MessageCircle className="w-4 h-4 fill-black" />
            </a>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-slate-300 hover:text-white bg-[#0f1d16] border border-[#22c55e]/30 rounded-xl"
              aria-label="Abrir Menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Dropdown Menu */}
        {mobileMenuOpen && (
          <div className="sm:hidden mt-3 pt-3 pb-4 border-t border-[#22c55e]/20 bg-[#0a1510]/95 backdrop-blur-xl rounded-2xl px-4 shadow-2xl border">
            <div className="flex flex-col gap-2">
              {navLinks.map((link) => (
                <a
                  key={link.label}
                  href={link.href}
                  onClick={(e) => handleNavClick(e, link.href)}
                  className="px-3 py-2.5 text-base font-semibold text-slate-200 hover:text-[#22c55e] hover:bg-[#22c55e]/10 rounded-xl transition"
                >
                  {link.label}
                </a>
              ))}

              {onOpenReviewModal && (
                <button
                  onClick={() => {
                    setMobileMenuOpen(false);
                    onOpenReviewModal();
                  }}
                  className="flex items-center gap-2 px-3 py-2.5 text-base font-semibold text-[#4ade80] bg-[#163323] rounded-xl border border-[#22c55e]/30 text-left"
                >
                  <Star className="w-4 h-4 fill-[#fbbf24] text-[#fbbf24]" />
                  <span>Avaliar Meu Site (Deixar Depoimento)</span>
                </button>
              )}

              <div className="pt-3 mt-1 border-t border-slate-800/80 flex flex-col gap-2">
                <a
                  href={whatsappUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={() => trackLeadClick('mobile_menu_cta')}
                  className="flex items-center justify-center gap-2 w-full bg-[#22c55e] text-black font-extrabold py-3 rounded-xl shadow-lg"
                >
                  <MessageCircle className="w-5 h-5 fill-black" />
                  <span>Fale Comigo no WhatsApp</span>
                </a>

                <div className="flex items-center justify-between text-xs text-slate-400 px-2 pt-1">
                  <span>{phoneFormatted}</span>
                  <button
                    onClick={() => {
                      setMobileMenuOpen(false);
                      onOpenAdmin();
                    }}
                    className="text-[#22c55e] hover:underline flex items-center gap-1 font-medium"
                  >
                    <Settings className="w-3.5 h-3.5" />
                    <span>Painel de Gestão</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </header>
  );
}
