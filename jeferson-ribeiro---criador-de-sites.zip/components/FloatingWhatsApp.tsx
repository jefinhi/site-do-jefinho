'use client';

import { useState } from 'react';
import { MessageCircle, X } from 'lucide-react';
import { getWhatsAppUrl, trackLeadClick } from '@/lib/whatsapp-utils';

interface FloatingWhatsAppProps {
  phoneRaw: string;
  phoneFormatted: string;
}

export function FloatingWhatsApp({ phoneRaw, phoneFormatted }: FloatingWhatsAppProps) {
  const [showBubble, setShowBubble] = useState(true);

  const whatsappUrl = getWhatsAppUrl(
    phoneRaw,
    'Olá Jeferson! Vi seu portfólio online e gostaria de tirar uma dúvida sobre criação de site.'
  );

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end gap-2 group">
      {/* Speech Bubble / Notification Badge */}
      {showBubble && (
        <div className="relative bg-[#0d2116] border border-[#22c55e]/50 text-white text-xs py-2 px-3.5 rounded-2xl shadow-2xl flex items-center gap-2 animate-bounce">
          <div className="w-2 h-2 rounded-full bg-[#22c55e] animate-ping" />
          <span>Fale comigo no WhatsApp!</span>
          <button
            onClick={() => setShowBubble(false)}
            className="text-slate-400 hover:text-white ml-1"
            title="Fechar aviso"
          >
            <X className="w-3 h-3" />
          </button>
          {/* Arrow */}
          <div className="absolute -bottom-1.5 right-6 w-3 h-3 bg-[#0d2116] border-r border-b border-[#22c55e]/50 rotate-45" />
        </div>
      )}

      {/* Floating Button with Green Ping Animation */}
      <a
        href={whatsappUrl}
        target="_blank"
        rel="noopener noreferrer"
        onClick={() => trackLeadClick('floating_whatsapp_button')}
        className="relative flex items-center justify-center w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-[#22c55e] text-black shadow-[0_0_25px_rgba(34,197,94,0.6)] hover:scale-110 active:scale-95 transition-all duration-300"
        aria-label={`Conversar no WhatsApp ${phoneFormatted}`}
      >
        {/* Pulsing ring */}
        <span className="absolute inset-0 rounded-full bg-[#22c55e] animate-ping opacity-40 pointer-events-none" />

        <MessageCircle className="w-7 h-7 sm:w-8 sm:h-8 fill-black text-black" />
      </a>
    </div>
  );
}
