'use client';

import { BrandLogo } from './BrandLogo';
import {
  MessageCircle,
  Instagram,
  Facebook,
  Youtube,
  Shield,
  Settings,
  Heart,
} from 'lucide-react';
import { getWhatsAppUrl, trackLeadClick } from '@/lib/whatsapp-utils';

interface FooterProps {
  phoneRaw: string;
  phoneFormatted: string;
  onOpenAdmin: () => void;
}

export function Footer({ phoneRaw, phoneFormatted, onOpenAdmin }: FooterProps) {
  const whatsappUrl = getWhatsAppUrl(
    phoneRaw,
    'Olá Jeferson! Gostaria de falar sobre um projeto para o meu site.'
  );

  const navLinks = [
    { label: 'Início', href: '#inicio' },
    { label: 'Serviços', href: '#servicos' },
    { label: 'Portfólio', href: '#portfolio' },
    { label: 'Depoimentos', href: '#depoimentos' },
    { label: 'Contato', href: '#contato' },
  ];

  return (
    <footer className="bg-[#050b07] border-t border-[#22c55e]/20 pt-12 pb-8 text-slate-400 text-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col lg:flex-row items-center justify-between gap-8 pb-10 border-b border-slate-800/80">
          {/* Brand Logo & Script Tagline */}
          <div className="flex flex-col sm:flex-row items-center gap-4 text-center sm:text-left">
            <BrandLogo size="lg" />
            <div className="hidden sm:block h-8 w-px bg-slate-800" />
            <span className="text-xs sm:text-sm italic font-serif text-slate-300">
              Seu sucesso também é o meu <span className="text-[#22c55e] font-sans font-bold not-italic">objetivo!</span>
            </span>
          </div>

          {/* Social Icons matching image.png */}
          <div className="flex items-center gap-3">
            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => trackLeadClick('footer_social_whatsapp')}
              className="w-10 h-10 rounded-full bg-[#0e2117] border border-[#22c55e]/30 hover:border-[#22c55e] hover:bg-[#22c55e] hover:text-black flex items-center justify-center text-[#22c55e] transition"
              title="WhatsApp"
            >
              <MessageCircle className="w-5 h-5 fill-current" />
            </a>

            <a
              href="https://instagram.com"
              target="_blank"
              rel="noopener noreferrer"
              className="w-10 h-10 rounded-full bg-[#0e2117] border border-[#22c55e]/30 hover:border-[#22c55e] hover:bg-[#22c55e] hover:text-black flex items-center justify-center text-slate-300 hover:text-black transition"
              title="Instagram"
            >
              <Instagram className="w-5 h-5" />
            </a>

            <a
              href="https://facebook.com"
              target="_blank"
              rel="noopener noreferrer"
              className="w-10 h-10 rounded-full bg-[#0e2117] border border-[#22c55e]/30 hover:border-[#22c55e] hover:bg-[#22c55e] hover:text-black flex items-center justify-center text-slate-300 hover:text-black transition"
              title="Facebook"
            >
              <Facebook className="w-5 h-5" />
            </a>

            <a
              href="https://youtube.com"
              target="_blank"
              rel="noopener noreferrer"
              className="w-10 h-10 rounded-full bg-[#0e2117] border border-[#22c55e]/30 hover:border-[#22c55e] hover:bg-[#22c55e] hover:text-black flex items-center justify-center text-slate-300 hover:text-black transition"
              title="YouTube"
            >
              <Youtube className="w-5 h-5" />
            </a>
          </div>
        </div>

        {/* Bottom Bar: Links, Admin Access & Copyright */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-6 text-xs text-slate-500">
          <div className="flex flex-wrap items-center justify-center gap-4 text-slate-400">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                className="hover:text-[#22c55e] transition"
              >
                {link.label}
              </a>
            ))}
            <button
              onClick={onOpenAdmin}
              className="hover:text-[#22c55e] flex items-center gap-1 transition ml-2 text-slate-400"
            >
              <Settings className="w-3.5 h-3.5" />
              <span>Painel de Gestão</span>
            </button>
          </div>

          <div className="flex items-center gap-2">
            <span>© 2025 Jeferson Ribeiro - Criador de Sites. Todos os direitos reservados.</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
