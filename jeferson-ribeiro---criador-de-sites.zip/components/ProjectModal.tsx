'use client';

import { useState } from 'react';
import Image from 'next/image';
import { Project } from '@/lib/portfolio-data';
import {
  X,
  ExternalLink,
  MessageCircle,
  CheckCircle,
  Smartphone,
  Monitor,
  Sparkles,
  ShieldCheck,
  TrendingUp,
} from 'lucide-react';
import { getWhatsAppUrl, trackLeadClick } from '@/lib/whatsapp-utils';

interface ProjectModalProps {
  project: Project | null;
  phoneRaw: string;
  phoneFormatted: string;
  onClose: () => void;
}

export function ProjectModal({ project, phoneRaw, phoneFormatted, onClose }: ProjectModalProps) {
  const [deviceView, setDeviceView] = useState<'desktop' | 'mobile'>('desktop');

  if (!project) return null;

  const whatsappMessage = `Olá Jeferson! Vi o projeto "${project.title}" no seu portfólio e gostaria de um site semelhante para o meu negócio. Como podemos conversar?`;
  const whatsappUrl = getWhatsAppUrl(phoneRaw, whatsappMessage);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-md overflow-y-auto animate-fadeIn">
      <div className="relative w-full max-w-4xl bg-[#0a1510] border border-[#22c55e]/50 rounded-3xl shadow-[0_0_50px_rgba(34,197,94,0.25)] overflow-hidden my-auto max-h-[90vh] flex flex-col">
        {/* Modal Top Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#22c55e]/20 bg-[#070e0a]">
          <div className="flex items-center gap-3">
            <span className="w-3 h-3 rounded-full bg-[#22c55e] animate-pulse" />
            <div>
              <h3 className="text-lg font-black text-white">{project.title}</h3>
              <p className="text-xs text-[#22c55e] font-medium">{project.subtitle}</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* View Mode Toggle */}
            <div className="hidden sm:flex items-center bg-[#0e1f16] p-1 rounded-xl border border-slate-800 text-xs">
              <button
                onClick={() => setDeviceView('desktop')}
                className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg transition ${
                  deviceView === 'desktop'
                    ? 'bg-[#22c55e] text-black font-bold shadow'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Monitor className="w-3.5 h-3.5" />
                <span>Computador</span>
              </button>
              <button
                onClick={() => setDeviceView('mobile')}
                className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg transition ${
                  deviceView === 'mobile'
                    ? 'bg-[#22c55e] text-black font-bold shadow'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Smartphone className="w-3.5 h-3.5" />
                <span>Celular</span>
              </button>
            </div>

            {/* Close Button */}
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white hover:bg-white/10 rounded-full transition"
              aria-label="Fechar"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body: Scrollable */}
        <div className="overflow-y-auto p-6 space-y-6">
          {/* Main Visual Display */}
          <div className="flex justify-center bg-[#050b07] p-4 rounded-2xl border border-slate-800">
            <div
              className={`transition-all duration-300 relative rounded-xl overflow-hidden border border-[#22c55e]/30 shadow-2xl ${
                deviceView === 'mobile'
                  ? 'w-[320px] aspect-[9/16] max-h-[420px]'
                  : 'w-full aspect-[16/9] max-h-[380px]'
              }`}
            >
              <Image
                src={project.image}
                alt={project.title}
                fill
                className="object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex items-end p-4">
                <a
                  href={project.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={() => trackLeadClick('modal_open_real_site', project.title)}
                  className="inline-flex items-center gap-2 bg-[#22c55e] text-black font-bold text-xs px-4 py-2 rounded-xl shadow-lg hover:bg-[#20b857] transition"
                >
                  <span>Abrir Site Real ({project.url.replace('https://', '')})</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>
          </div>

          {/* Description & Highlights */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="text-sm font-bold uppercase tracking-wider text-[#22c55e] mb-2 flex items-center gap-1.5">
                <Sparkles className="w-4 h-4" />
                Sobre este projeto
              </h4>
              <p className="text-sm text-slate-300 leading-relaxed mb-4">
                {project.description}
              </p>

              <div className="bg-[#0f241a] border border-[#22c55e]/30 p-3.5 rounded-xl">
                <span className="text-xs font-semibold text-[#4ade80] block mb-1">
                  Avaliação do Cliente:
                </span>
                <p className="text-xs text-slate-200 italic">
                  &ldquo;{project.reviewSnippet}&rdquo;
                </p>
                <span className="text-[10px] text-slate-400 block mt-1 font-medium">
                  — {project.client}
                </span>
              </div>
            </div>

            <div>
              <h4 className="text-sm font-bold uppercase tracking-wider text-[#22c55e] mb-2 flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4" />
                Recursos Implementados
              </h4>
              <ul className="space-y-2 text-xs text-slate-300 mb-4">
                {project.features.map((feat, i) => (
                  <li key={i} className="flex items-start gap-2">
                    <CheckCircle className="w-3.5 h-3.5 text-[#22c55e] shrink-0 mt-0.5" />
                    <span>{feat}</span>
                  </li>
                ))}
              </ul>

              <div className="flex flex-wrap gap-1.5 pt-2">
                {project.tags.map((tag, idx) => (
                  <span
                    key={idx}
                    className="text-[11px] font-medium bg-[#143224] text-[#4ade80] border border-[#22c55e]/30 px-2.5 py-1 rounded-lg"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Modal Bottom Actions */}
        <div className="px-6 py-4 bg-[#070e0a] border-t border-[#22c55e]/20 flex flex-col sm:flex-row items-center justify-between gap-3">
          <a
            href={project.url}
            target="_blank"
            rel="noopener noreferrer"
            onClick={() => trackLeadClick('modal_bottom_open_site', project.title)}
            className="flex items-center gap-2 text-sm text-slate-300 hover:text-white transition order-2 sm:order-1"
          >
            <ExternalLink className="w-4 h-4 text-[#22c55e]" />
            <span>Visitar {project.url.replace('https://', '')}</span>
          </a>

          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            onClick={() => trackLeadClick('modal_solicitar_site_whatsapp', project.title)}
            className="w-full sm:w-auto flex items-center justify-center gap-2 bg-[#22c55e] hover:bg-[#20b857] text-black font-extrabold text-sm px-6 py-3 rounded-xl shadow-[0_0_20px_rgba(34,197,94,0.4)] transition order-1 sm:order-2"
          >
            <MessageCircle className="w-4 h-4 fill-black" />
            <span>Quero um site como esse no WhatsApp</span>
          </a>
        </div>
      </div>
    </div>
  );
}
