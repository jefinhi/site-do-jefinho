'use client';

import { useState } from 'react';
import Image from 'next/image';
import { Testimonial } from '@/lib/portfolio-data';
import { Star, CheckCircle, Quote, ThumbsUp, ExternalLink, MessageSquarePlus, Sparkles } from 'lucide-react';

interface TestimonialsProps {
  testimonials: Testimonial[];
  onOpenReviewModal: () => void;
  onLikeTestimonial?: (id: string) => void;
}

export function Testimonials({
  testimonials,
  onOpenReviewModal,
  onLikeTestimonial,
}: TestimonialsProps) {
  const [filter, setFilter] = useState<'todos' | 'com_link'>('todos');
  const [likedMap, setLikedMap] = useState<Record<string, boolean>>({});

  const handleLike = (id: string) => {
    if (likedMap[id]) return;
    setLikedMap((prev) => ({ ...prev, [id]: true }));
    if (onLikeTestimonial) {
      onLikeTestimonial(id);
    }
  };

  const filteredTestimonials = testimonials.filter((item) => {
    if (filter === 'com_link') return !!item.websiteUrl;
    return true;
  });

  // Calculate average rating
  const avgRating = (
    testimonials.reduce((acc, t) => acc + t.stars, 0) / (testimonials.length || 1)
  ).toFixed(1);

  return (
    <section
      id="depoimentos"
      className="relative py-20 sm:py-28 bg-[#070e0a] border-t border-b border-[#22c55e]/15 overflow-hidden"
    >
      {/* Background ambient lighting */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[350px] bg-[#22c55e]/5 blur-[160px] rounded-full pointer-events-none" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#163323] border border-[#22c55e]/40 text-[#4ade80] text-xs font-semibold mb-3">
            <Quote className="w-3 h-3 text-[#22c55e]" />
            <span>DEPOIMENTOS & AVALIAÇÕES DE CLIENTES</span>
          </div>

          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black text-white tracking-tight mb-4">
            Clientes que <span className="text-[#22c55e]">confiam e aprovam</span>
          </h2>

          <p className="text-base sm:text-lg text-slate-300 leading-relaxed mb-6">
            A satisfação dos meus clientes é o que me motiva a continuar fazendo o meu melhor.
          </p>

          {/* Social Proof & Quick Review Action Button */}
          <div className="flex flex-wrap items-center justify-center gap-4 pt-2">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-[#0b1711] border border-slate-800 text-xs text-slate-300">
              <div className="flex items-center gap-0.5">
                {[1, 2, 3, 4, 5].map((s) => (
                  <Star key={s} className="w-3.5 h-3.5 fill-[#fbbf24] text-[#fbbf24]" />
                ))}
              </div>
              <span className="font-bold text-white">{avgRating}</span>
              <span className="text-slate-500">|</span>
              <span className="text-slate-300">{testimonials.length} avaliações reais</span>
            </div>

            {/* BOTÃO DE AVALIAÇÃO PRINCIPAL */}
            <button
              id="btn-abrir-avaliacao-header"
              onClick={onOpenReviewModal}
              className="inline-flex items-center gap-2 px-5 py-2 rounded-xl bg-[#22c55e] hover:bg-[#1ea750] text-black text-xs font-black uppercase tracking-wider transition-all duration-300 hover:scale-105 shadow-md shadow-[#22c55e]/20 cursor-pointer"
            >
              <MessageSquarePlus className="w-4 h-4" />
              <span>Deixar Avaliação do Meu Site</span>
            </button>
          </div>
        </div>

        {/* Filter bar */}
        <div className="flex items-center justify-between gap-4 mb-8 flex-wrap">
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-slate-400">Filtrar:</span>
            <button
              onClick={() => setFilter('todos')}
              className={`px-3 py-1 rounded-lg text-xs font-semibold transition ${
                filter === 'todos'
                  ? 'bg-[#163323] text-[#4ade80] border border-[#22c55e]/50'
                  : 'text-slate-400 hover:text-white bg-slate-900/60 border border-slate-800'
              }`}
            >
              Todos ({testimonials.length})
            </button>
            <button
              onClick={() => setFilter('com_link')}
              className={`px-3 py-1 rounded-lg text-xs font-semibold transition ${
                filter === 'com_link'
                  ? 'bg-[#163323] text-[#4ade80] border border-[#22c55e]/50'
                  : 'text-slate-400 hover:text-white bg-slate-900/60 border border-slate-800'
              }`}
            >
              Com Site Criado Online ({testimonials.filter((t) => !!t.websiteUrl).length})
            </button>
          </div>

          <div className="text-xs text-slate-400 flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-[#22c55e]" />
            <span>Depoimentos reais de quem tirou o projeto do papel</span>
          </div>
        </div>

        {/* Testimonials Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {filteredTestimonials.map((item) => (
            <div
              key={item.id}
              className="bg-[#0b1711] border border-[#22c55e]/25 hover:border-[#22c55e]/60 p-6 rounded-2xl shadow-lg hover:shadow-[0_10px_25px_rgba(34,197,94,0.15)] transition-all duration-300 flex flex-col justify-between group relative"
            >
              <div>
                {/* User Header: Avatar, Name & Stars */}
                <div className="flex items-start gap-3 mb-4">
                  <div className="relative w-12 h-12 rounded-full overflow-hidden border-2 border-[#22c55e]/40 shadow-sm shrink-0 bg-slate-800">
                    <Image
                      src={item.avatar}
                      alt={item.name}
                      fill
                      className="object-cover"
                      sizes="48px"
                    />
                  </div>

                  <div className="flex flex-col min-w-0 flex-1">
                    <span className="text-sm font-black text-white leading-tight truncate">
                      {item.name}
                    </span>
                    <span className="text-[11px] text-[#4ade80] font-medium truncate">
                      {item.company}
                    </span>
                    {item.role && (
                      <span className="text-[10px] text-slate-400 truncate">
                        {item.role}
                      </span>
                    )}

                    {/* 5 Stars */}
                    <div className="flex items-center gap-0.5 mt-1">
                      {Array.from({ length: item.stars }).map((_, i) => (
                        <Star
                          key={i}
                          className="w-3 h-3 fill-[#fbbf24] text-[#fbbf24]"
                        />
                      ))}
                    </div>
                  </div>
                </div>

                {/* Testimonial Quote */}
                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed italic mb-4">
                  {item.text}
                </p>
              </div>

              <div>
                {/* Optional Link to the client's live website */}
                {item.websiteUrl && (
                  <a
                    href={item.websiteUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-[#163323]/60 hover:bg-[#163323] border border-[#22c55e]/30 text-[#4ade80] text-[11px] font-semibold transition mb-3 w-full justify-center group-hover:border-[#22c55e]/60"
                  >
                    <span>Ver site no ar</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                )}

                {/* Footer of Card: Date, Verified badge & Like button */}
                <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
                  <div className="flex items-center gap-1">
                    <CheckCircle className="w-3.5 h-3.5 text-[#22c55e]" />
                    <span>{item.date || 'Cliente Verificado'}</span>
                  </div>

                  <button
                    type="button"
                    onClick={() => handleLike(item.id)}
                    className={`flex items-center gap-1 px-2 py-0.5 rounded transition ${
                      likedMap[item.id]
                        ? 'text-[#22c55e] font-semibold'
                        : 'text-slate-400 hover:text-white'
                    }`}
                    title="Marcar como útil"
                  >
                    <ThumbsUp className="w-3 h-3" />
                    <span>{(item.likes || 0) + (likedMap[item.id] ? 1 : 0)}</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* ESPAÇO PARA COMENTÁRIOS / CALLOUT DE CONVITE */}
        <div className="mt-14 p-6 sm:p-8 rounded-2xl bg-gradient-to-r from-[#0b1711] via-[#102419] to-[#0b1711] border border-[#22c55e]/30 flex flex-col md:flex-row items-center justify-between gap-6 shadow-xl">
          <div className="space-y-1.5 text-center md:text-left">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-[#22c55e]/20 text-[#4ade80] text-[11px] font-bold">
              <Sparkles className="w-3 h-3 text-[#22c55e]" />
              <span>SEU NEGÓCIO NO DIGITAL</span>
            </div>
            <h3 className="text-lg sm:text-xl font-black text-white">
              Você já fez seu site com o Jeferson Ribeiro?
            </h3>
            <p className="text-xs sm:text-sm text-slate-300 max-w-xl leading-relaxed">
              Deixe sua avaliação com estrelas e conte para novos clientes como foi sua experiência, o atendimento e o aumento nas suas vendas!
            </p>
          </div>

          <div className="shrink-0">
            <button
              id="btn-abrir-avaliacao-bottom"
              onClick={onOpenReviewModal}
              className="inline-flex items-center gap-2.5 px-6 py-3.5 rounded-xl bg-[#22c55e] hover:bg-[#1ea750] text-black font-black text-sm uppercase tracking-wider transition-all duration-300 hover:scale-105 shadow-lg shadow-[#22c55e]/30 cursor-pointer"
            >
              <MessageSquarePlus className="w-4 h-4" />
              <span>Escrever Avaliação Agora</span>
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}

