'use client';

import { useState } from 'react';
import { X, Star, CheckCircle, Send, Globe, User, Building2, Briefcase, MessageSquare, Heart } from 'lucide-react';
import { Testimonial, SiteConfig } from '@/lib/portfolio-data';
import { getWhatsAppUrl } from '@/lib/whatsapp-utils';

interface ReviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (review: Testimonial) => void;
  siteConfig: SiteConfig;
}

const AVATAR_PRESETS = [
  { id: '1', label: 'Mulher 1', url: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&auto=format&fit=crop&q=80' },
  { id: '2', label: 'Homem 1', url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80' },
  { id: '3', label: 'Mulher 2', url: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80' },
  { id: '4', label: 'Homem 2', url: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80' },
  { id: '5', label: 'Mulher 3', url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80' },
  { id: '6', label: 'Homem 3', url: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&auto=format&fit=crop&q=80' },
];

const RATING_DESCRIPTIONS: Record<number, string> = {
  5: '⭐⭐⭐⭐⭐ Excelente! Superou todas as expectativas',
  4: '⭐⭐⭐⭐ Muito bom! Trabalho ágil e profissional',
  3: '⭐⭐⭐ Bom, atendeu ao que foi contratado',
  2: '⭐⭐ Regular',
  1: '⭐ Não fiquei satisfeito',
};

export function ReviewModal({ isOpen, onClose, onSubmit, siteConfig }: ReviewModalProps) {
  const [stars, setStars] = useState<number>(5);
  const [hoverStars, setHoverStars] = useState<number | null>(null);
  const [name, setName] = useState('');
  const [company, setCompany] = useState('');
  const [role, setRole] = useState('Cliente / Proprietário');
  const [websiteUrl, setWebsiteUrl] = useState('');
  const [text, setText] = useState('');
  const [selectedAvatar, setSelectedAvatar] = useState(AVATAR_PRESETS[0].url);
  const [sendToWhatsApp, setSendToWhatsApp] = useState(true);
  const [submitted, setSubmitted] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setErrorMsg('Por favor, informe o seu nome.');
      return;
    }
    if (!company.trim()) {
      setErrorMsg('Por favor, informe o nome do seu negócio ou projeto.');
      return;
    }
    if (!text.trim() || text.trim().length < 8) {
      setErrorMsg('Por favor, escreva um comentário de pelo menos 8 caracteres.');
      return;
    }

    const newReview: Testimonial = {
      id: `review-${Date.now()}`,
      name: name.trim(),
      role: role.trim() || 'Cliente',
      company: company.trim(),
      avatar: selectedAvatar,
      stars,
      text: `“${text.trim().replace(/^["“]+|["”]+$/g, '')}”`,
      verified: true,
      date: 'Publicado hoje',
      websiteUrl: websiteUrl.trim() ? (websiteUrl.startsWith('http') ? websiteUrl.trim() : `https://${websiteUrl.trim()}`) : undefined,
      likes: 1,
    };

    onSubmit(newReview);
    setSubmitted(true);

    if (sendToWhatsApp) {
      const waMsg = `⭐ *NOVA AVALIAÇÃO DE CLIENTE NO SITE* ⭐\n\n` +
        `👤 *Cliente:* ${name.trim()} (${role.trim()})\n` +
        `🏢 *Negócio/Site:* ${company.trim()}\n` +
        `⭐ *Nota:* ${stars}/5 estrelas\n` +
        (websiteUrl.trim() ? `🌐 *Site:* ${websiteUrl.trim()}\n` : '') +
        `💬 *Depoimento:* "${text.trim()}"\n\n` +
        `_Enviado pelo formulário de avaliação do seu portfólio oficial._`;
      
      const waUrl = getWhatsAppUrl(siteConfig.phoneRaw, waMsg);
      setTimeout(() => {
        window.open(waUrl, '_blank');
      }, 700);
    }
  };

  const handleResetAndClose = () => {
    setSubmitted(false);
    setName('');
    setCompany('');
    setRole('Cliente / Proprietário');
    setWebsiteUrl('');
    setText('');
    setStars(5);
    setErrorMsg('');
    onClose();
  };

  return (
    <div
      id="modal-avaliacao-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm overflow-y-auto animate-fadeIn"
      onClick={(e) => {
        if (e.target === e.currentTarget) handleResetAndClose();
      }}
    >
      <div
        id="modal-avaliacao-container"
        className="relative w-full max-w-xl bg-[#0b1711] border border-[#22c55e]/30 rounded-2xl shadow-2xl p-6 sm:p-8 text-white my-8 max-h-[92vh] overflow-y-auto"
      >
        {/* Close Button */}
        <button
          id="btn-fechar-modal-avaliacao"
          onClick={handleResetAndClose}
          className="absolute top-4 right-4 p-2 rounded-xl text-slate-400 hover:text-white hover:bg-white/10 transition"
          aria-label="Fechar modal"
        >
          <X className="w-5 h-5" />
        </button>

        {submitted ? (
          /* Success Screen */
          <div className="text-center py-8 space-y-4">
            <div className="w-16 h-16 bg-[#22c55e]/20 border border-[#22c55e] rounded-full flex items-center justify-center mx-auto text-[#22c55e]">
              <CheckCircle className="w-9 h-9" />
            </div>

            <h3 className="text-2xl font-black text-white">
              Avaliação Publicada com Sucesso!
            </h3>

            <p className="text-slate-300 text-sm max-w-md mx-auto leading-relaxed">
              Muito obrigado pelo seu carinho, <span className="text-[#22c55e] font-semibold">{name}</span>!
              Seu depoimento já está visível na seção de clientes do site do Jeferson Ribeiro.
            </p>

            <div className="pt-4 flex flex-col sm:flex-row gap-3 justify-center">
              <button
                id="btn-concluir-avaliacao"
                onClick={handleResetAndClose}
                className="px-6 py-3 rounded-xl bg-[#22c55e] hover:bg-[#1ea750] text-black font-black text-sm transition shadow-lg shadow-[#22c55e]/20"
              >
                Ver Meu Comentário no Site
              </button>
            </div>
          </div>
        ) : (
          /* Review Form */
          <div>
            {/* Header */}
            <div className="mb-6">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#163323] border border-[#22c55e]/40 text-[#4ade80] text-xs font-semibold mb-2">
                <Heart className="w-3.5 h-3.5 text-[#22c55e] fill-[#22c55e]" />
                <span>ESPAÇO DE AVALIAÇÃO DO CLIENTE</span>
              </div>
              <h3 className="text-2xl font-black text-white">
                Avalie o Site Criado pelo Jeferson
              </h3>
              <p className="text-slate-300 text-xs sm:text-sm mt-1 leading-relaxed">
                Conte sua experiência, como foi o atendimento e o resultado alcançado com o seu novo site.
              </p>
            </div>

            {errorMsg && (
              <div className="mb-4 p-3 rounded-xl bg-red-950/60 border border-red-500/40 text-red-200 text-xs">
                {errorMsg}
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Star Rating Selector */}
              <div className="bg-[#070e0a] p-4 rounded-xl border border-slate-800 text-center">
                <label className="block text-xs font-semibold text-slate-300 mb-2 uppercase tracking-wider">
                  Sua Nota Geral para o Serviço
                </label>
                <div className="flex items-center justify-center gap-2">
                  {[1, 2, 3, 4, 5].map((starValue) => {
                    const isFilled = (hoverStars !== null ? hoverStars : stars) >= starValue;
                    return (
                      <button
                        type="button"
                        key={starValue}
                        onClick={() => setStars(starValue)}
                        onMouseEnter={() => setHoverStars(starValue)}
                        onMouseLeave={() => setHoverStars(null)}
                        className="p-1 transition-transform hover:scale-125 focus:outline-none"
                        aria-label={`Avaliar com ${starValue} estrelas`}
                      >
                        <Star
                          className={`w-8 h-8 transition-colors ${
                            isFilled
                              ? 'fill-[#fbbf24] text-[#fbbf24] drop-shadow-[0_0_8px_rgba(251,191,36,0.6)]'
                              : 'text-slate-600 hover:text-slate-400'
                          }`}
                        />
                      </button>
                    );
                  })}
                </div>
                <div className="mt-2 text-xs font-medium text-[#4ade80]">
                  {RATING_DESCRIPTIONS[hoverStars !== null ? hoverStars : stars]}
                </div>
              </div>

              {/* Name & Role Inputs */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1 flex items-center gap-1.5">
                    <User className="w-3.5 h-3.5 text-[#22c55e]" />
                    <span>Seu Nome Completo *</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Ex: Amanda Ferreira"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#070e0a] border border-slate-700 text-white text-sm focus:outline-none focus:border-[#22c55e] transition"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1 flex items-center gap-1.5">
                    <Briefcase className="w-3.5 h-3.5 text-[#22c55e]" />
                    <span>Seu Cargo / Função</span>
                  </label>
                  <input
                    type="text"
                    value={role}
                    onChange={(e) => setRole(e.target.value)}
                    placeholder="Ex: Proprietária, Gerente, Fundador"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#070e0a] border border-slate-700 text-white text-sm focus:outline-none focus:border-[#22c55e] transition"
                  />
                </div>
              </div>

              {/* Business Name & Website URL */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1 flex items-center gap-1.5">
                    <Building2 className="w-3.5 h-3.5 text-[#22c55e]" />
                    <span>Nome do Seu Negócio / Site *</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={company}
                    onChange={(e) => setCompany(e.target.value)}
                    placeholder="Ex: Bella Estética, Padaria Imperial"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#070e0a] border border-slate-700 text-white text-sm focus:outline-none focus:border-[#22c55e] transition"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1 flex items-center gap-1.5">
                    <Globe className="w-3.5 h-3.5 text-[#22c55e]" />
                    <span>Link do Site Criado (Opcional)</span>
                  </label>
                  <input
                    type="text"
                    value={websiteUrl}
                    onChange={(e) => setWebsiteUrl(e.target.value)}
                    placeholder="Ex: https://meusite.com.br"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#070e0a] border border-slate-700 text-white text-sm focus:outline-none focus:border-[#22c55e] transition"
                  />
                </div>
              </div>

              {/* Avatar Preset Choice */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-2">
                  Escolha uma foto de perfil:
                </label>
                <div className="flex items-center gap-2 overflow-x-auto pb-1">
                  {AVATAR_PRESETS.map((av) => (
                    <button
                      type="button"
                      key={av.id}
                      onClick={() => setSelectedAvatar(av.url)}
                      className={`relative w-11 h-11 rounded-full overflow-hidden border-2 transition-transform shrink-0 ${
                        selectedAvatar === av.url
                          ? 'border-[#22c55e] scale-110 shadow-[0_0_10px_rgba(34,197,94,0.6)]'
                          : 'border-slate-700 opacity-60 hover:opacity-100'
                      }`}
                    >
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img
                        src={av.url}
                        alt={av.label}
                        className="w-full h-full object-cover"
                      />
                    </button>
                  ))}
                </div>
              </div>

              {/* Comment / Review Textarea */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1 flex items-center gap-1.5">
                  <MessageSquare className="w-3.5 h-3.5 text-[#22c55e]" />
                  <span>Seu Comentário / Depoimento *</span>
                </label>
                <textarea
                  required
                  rows={4}
                  value={text}
                  onChange={(e) => setText(e.target.value)}
                  placeholder="Ex: O Jeferson entregou o site antes do prazo combinado! Ficou lindo, super rápido no celular e meus clientes adoraram. Já comecei a receber contatos no WhatsApp na primeira semana..."
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#070e0a] border border-slate-700 text-white text-sm focus:outline-none focus:border-[#22c55e] transition resize-none leading-relaxed"
                />
                <div className="text-[11px] text-slate-400 text-right mt-0.5">
                  {text.length} caracteres
                </div>
              </div>

              {/* WhatsApp notification option */}
              <label className="flex items-center gap-2.5 p-3 rounded-xl bg-[#163323]/50 border border-[#22c55e]/25 cursor-pointer text-xs text-slate-300 hover:bg-[#163323]/80 transition">
                <input
                  type="checkbox"
                  checked={sendToWhatsApp}
                  onChange={(e) => setSendToWhatsApp(e.target.checked)}
                  className="w-4 h-4 rounded text-[#22c55e] focus:ring-[#22c55e] accent-[#22c55e]"
                />
                <span>
                  Enviar também uma cópia no <strong>WhatsApp do Jeferson</strong> para que ele receba sua mensagem de carinho
                </span>
              </label>

              {/* Submit Buttons */}
              <div className="pt-2 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={handleResetAndClose}
                  className="px-4 py-2.5 rounded-xl text-slate-400 hover:text-white hover:bg-white/5 text-sm font-medium transition"
                >
                  Cancelar
                </button>

                <button
                  type="submit"
                  id="btn-salvar-avaliacao"
                  className="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl bg-[#22c55e] hover:bg-[#1ea750] text-black font-black text-sm transition shadow-lg shadow-[#22c55e]/20"
                >
                  <Send className="w-4 h-4" />
                  <span>Publicar Avaliação</span>
                </button>
              </div>
            </form>
          </div>
        )}
      </div>
    </div>
  );
}
