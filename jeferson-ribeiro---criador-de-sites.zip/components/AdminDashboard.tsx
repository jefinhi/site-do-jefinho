'use client';

import { useState, useEffect } from 'react';
import { Project, SiteConfig, INITIAL_PROJECTS, INITIAL_CONFIG, Testimonial, TESTIMONIALS_DATA } from '@/lib/portfolio-data';
import { getLeadClicks, LeadClickEvent, getWhatsAppUrl } from '@/lib/whatsapp-utils';
import {
  X,
  Plus,
  Trash2,
  Edit2,
  Check,
  Globe,
  Phone,
  QrCode,
  BarChart3,
  ExternalLink,
  Save,
  RotateCcw,
  Sparkles,
  Share2,
  Smartphone,
  CheckCircle2,
  Download,
  Star,
  MessageSquare,
} from 'lucide-react';
import QRCode from 'qrcode';

interface AdminDashboardProps {
  isOpen: boolean;
  onClose: () => void;
  projects: Project[];
  onUpdateProjects: (updated: Project[]) => void;
  siteConfig: SiteConfig;
  onUpdateConfig: (config: SiteConfig) => void;
  testimonials: Testimonial[];
  onUpdateTestimonials: (testimonials: Testimonial[]) => void;
}

export function AdminDashboard({
  isOpen,
  onClose,
  projects,
  onUpdateProjects,
  siteConfig,
  onUpdateConfig,
  testimonials,
  onUpdateTestimonials,
}: AdminDashboardProps) {
  const [activeTab, setActiveTab] = useState<'projetos' | 'whatsapp' | 'qrcode' | 'leads' | 'facebook' | 'avaliacoes'>('projetos');
  const [leadList, setLeadList] = useState<LeadClickEvent[]>([]);
  const [editingProjectId, setEditingProjectId] = useState<string | null>(null);

  // New review manual addition in admin
  const [isAddingReview, setIsAddingReview] = useState(false);
  const [newReviewForm, setNewReviewForm] = useState<Partial<Testimonial>>({
    name: '',
    role: 'Cliente',
    company: '',
    stars: 5,
    text: '',
    websiteUrl: '',
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&auto=format&fit=crop&q=80',
  });

  // Form states
  const [phoneInput, setPhoneInput] = useState(siteConfig.phoneRaw);
  const [phoneFormattedInput, setPhoneFormattedInput] = useState(siteConfig.phoneFormatted);
  const [messageInput, setMessageInput] = useState(siteConfig.whatsappMessageDefault);
  const [saveSuccess, setSaveSuccess] = useState(false);

  // QR Code generator
  const [qrText, setQrText] = useState('');
  const [generatedQrData, setGeneratedQrData] = useState('');

  // Add new project state
  const [isAddingProject, setIsAddingProject] = useState(false);
  const [newProject, setNewProject] = useState<Partial<Project>>({
    title: '',
    subtitle: '',
    category: 'confeitaria',
    categoryLabel: 'Outro',
    description: '',
    url: 'https://',
    image: '/images/mockup_delicias_tati.jpg',
    tags: ['Responsivo', 'WhatsApp'],
    features: ['Design personalizado', 'Mobile first'],
    status: 'online',
  });

  useEffect(() => {
    if (!isOpen) return;
    const testUrl = getWhatsAppUrl(siteConfig.phoneRaw, siteConfig.whatsappMessageDefault);
    QRCode.toDataURL(testUrl, { width: 500, margin: 2, errorCorrectionLevel: 'H' }).then((url) => {
      setGeneratedQrData(url);
      setQrText(testUrl);
      setLeadList(getLeadClicks());
    });
  }, [isOpen, siteConfig]);

  if (!isOpen) return null;

  const handleSaveConfig = (e: React.FormEvent) => {
    e.preventDefault();
    const updated = {
      ...siteConfig,
      phoneRaw: phoneInput.replace(/\D/g, ''),
      phoneFormatted: phoneFormattedInput,
      whatsappMessageDefault: messageInput,
    };
    onUpdateConfig(updated);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 3000);
  };

  const handleUpdateProjectField = (id: string, field: keyof Project, value: any) => {
    const updated = projects.map((p) => {
      if (p.id === id) {
        return { ...p, [field]: value };
      }
      return p;
    });
    onUpdateProjects(updated);
  };

  const handleDeleteProject = (id: string) => {
    if (confirm('Deseja realmente remover este projeto do portfólio?')) {
      const updated = projects.filter((p) => p.id !== id);
      onUpdateProjects(updated);
    }
  };

  const handleCreateProject = () => {
    if (!newProject.title || !newProject.url) {
      alert('Por favor, preencha o título e o link do projeto.');
      return;
    }

    const created: Project = {
      id: 'proj-' + Date.now(),
      title: newProject.title || 'Novo Site',
      subtitle: newProject.subtitle || 'Site Profissional',
      category: newProject.category || 'todos',
      categoryLabel: newProject.categoryLabel || 'Web',
      description: newProject.description || 'Site moderno e responsivo.',
      url: newProject.url || 'https://',
      image: newProject.image || '/images/mockup_delicias_tati.jpg',
      tags: newProject.tags || ['Design Moderno'],
      features: newProject.features || ['Responsivo', 'Otimizado'],
      deliverables: ['Página Completa', 'WhatsApp Integrado'],
      client: 'Cliente Corporativo',
      reviewSnippet: 'Excelente trabalho na entrega do site.',
      viewsEstimate: '+1.000 acessos/mês',
      conversionRate: 'Alta conversão',
      status: 'online',
    };

    onUpdateProjects([created, ...projects]);
    setIsAddingProject(false);
    setNewProject({
      title: '',
      subtitle: '',
      category: 'confeitaria',
      categoryLabel: 'Outro',
      description: '',
      url: 'https://',
      image: '/images/mockup_delicias_tati.jpg',
      tags: ['Responsivo', 'WhatsApp'],
      features: ['Design personalizado'],
      status: 'online',
    });
  };

  const handleResetDefaults = () => {
    if (confirm('Deseja restaurar os projetos originais do portfólio?')) {
      onUpdateProjects(INITIAL_PROJECTS);
      onUpdateConfig(INITIAL_CONFIG);
      setPhoneInput(INITIAL_CONFIG.phoneRaw);
      setPhoneFormattedInput(INITIAL_CONFIG.phoneFormatted);
      setMessageInput(INITIAL_CONFIG.whatsappMessageDefault);
    }
  };

  const handleDownloadQr = () => {
    if (!generatedQrData) return;
    const a = document.createElement('a');
    a.href = generatedQrData;
    a.download = `qrcode-jeferson-ribeiro-${siteConfig.phoneRaw}.png`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md overflow-y-auto animate-fadeIn">
      <div className="relative w-full max-w-5xl bg-[#091510] border-2 border-[#22c55e]/40 rounded-3xl shadow-[0_0_60px_rgba(34,197,94,0.25)] overflow-hidden my-auto max-h-[92vh] flex flex-col">
        {/* Admin Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-[#050b07] border-b border-[#22c55e]/25">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-[#22c55e] text-black flex items-center justify-center font-black">
              JR
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-black text-white">
                  Painel Centralizado de Gestão
                </h2>
                <span className="bg-[#22c55e]/20 text-[#22c55e] border border-[#22c55e]/40 text-[10px] font-bold px-2 py-0.5 rounded-full uppercase">
                  Ativo
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Gerencie links do portfólio, WhatsApp, métricas de leads e campanhas do Facebook.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white hover:bg-white/10 rounded-full transition"
            aria-label="Fechar Painel"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-2 px-6 py-2.5 bg-[#0a1811] border-b border-slate-800 overflow-x-auto text-xs font-semibold">
          <button
            onClick={() => setActiveTab('projetos')}
            className={`px-3 py-1.5 rounded-xl transition flex items-center gap-1.5 shrink-0 ${
              activeTab === 'projetos'
                ? 'bg-[#22c55e] text-black font-extrabold shadow'
                : 'text-slate-300 hover:text-white hover:bg-white/5'
            }`}
          >
            <Globe className="w-3.5 h-3.5" />
            <span>Projetos do Portfólio ({projects.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('whatsapp')}
            className={`px-3 py-1.5 rounded-xl transition flex items-center gap-1.5 shrink-0 ${
              activeTab === 'whatsapp'
                ? 'bg-[#22c55e] text-black font-extrabold shadow'
                : 'text-slate-300 hover:text-white hover:bg-white/5'
            }`}
          >
            <Phone className="w-3.5 h-3.5" />
            <span>WhatsApp & Conversão</span>
          </button>

          <button
            onClick={() => setActiveTab('qrcode')}
            className={`px-3 py-1.5 rounded-xl transition flex items-center gap-1.5 shrink-0 ${
              activeTab === 'qrcode'
                ? 'bg-[#22c55e] text-black font-extrabold shadow'
                : 'text-slate-300 hover:text-white hover:bg-white/5'
            }`}
          >
            <QrCode className="w-3.5 h-3.5" />
            <span>Gerador de QR Code</span>
          </button>

          <button
            onClick={() => setActiveTab('leads')}
            className={`px-3 py-1.5 rounded-xl transition flex items-center gap-1.5 shrink-0 ${
              activeTab === 'leads'
                ? 'bg-[#22c55e] text-black font-extrabold shadow'
                : 'text-slate-300 hover:text-white hover:bg-white/5'
            }`}
          >
            <BarChart3 className="w-3.5 h-3.5" />
            <span>Cliques & Leads ({leadList.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('facebook')}
            className={`px-3 py-1.5 rounded-xl transition flex items-center gap-1.5 shrink-0 ${
              activeTab === 'facebook'
                ? 'bg-[#22c55e] text-black font-extrabold shadow'
                : 'text-slate-300 hover:text-white hover:bg-white/5'
            }`}
          >
            <Share2 className="w-3.5 h-3.5" />
            <span>Simulador Facebook Ads</span>
          </button>

          <button
            onClick={() => setActiveTab('avaliacoes')}
            className={`px-3 py-1.5 rounded-xl transition flex items-center gap-1.5 shrink-0 ${
              activeTab === 'avaliacoes'
                ? 'bg-[#22c55e] text-black font-extrabold shadow'
                : 'text-slate-300 hover:text-white hover:bg-white/5'
            }`}
          >
            <Star className="w-3.5 h-3.5 fill-current" />
            <span>Avaliações & Comentários ({testimonials.length})</span>
          </button>
        </div>

        {/* Tab Content Area */}
        <div className="overflow-y-auto p-6 flex-1 space-y-6">
          {/* TAB 1: PROJETOS */}
          {activeTab === 'projetos' && (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-[#0d2117] p-4 rounded-2xl border border-[#22c55e]/30">
                <div>
                  <h3 className="text-sm font-black text-white">
                    Sites Atualmente Integrados no Portfólio
                  </h3>
                  <p className="text-xs text-slate-300">
                    Você pode editar links, títulos e adicionar novos projetos a qualquer momento.
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setIsAddingProject(!isAddingProject)}
                    className="flex items-center gap-1.5 bg-[#22c55e] hover:bg-[#20b857] text-black font-extrabold text-xs px-4 py-2 rounded-xl transition"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Adicionar Novo Site</span>
                  </button>
                  <button
                    onClick={handleResetDefaults}
                    className="p-2 text-slate-400 hover:text-white border border-slate-700 rounded-xl transition"
                    title="Restaurar originais"
                  >
                    <RotateCcw className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Add Project Form */}
              {isAddingProject && (
                <div className="bg-[#0b1b13] border-2 border-[#22c55e]/60 p-5 rounded-2xl space-y-4">
                  <h4 className="text-sm font-bold text-[#4ade80] flex items-center gap-1.5">
                    <Plus className="w-4 h-4" />
                    Cadastrar Novo Projeto no Portfólio
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                    <div>
                      <label className="block text-slate-300 font-semibold mb-1">Título do Projeto</label>
                      <input
                        type="text"
                        placeholder="Ex: Minha Nova Loja"
                        value={newProject.title}
                        onChange={(e) => setNewProject({ ...newProject, title: e.target.value })}
                        className="w-full bg-[#050b07] border border-slate-700 rounded-xl p-2.5 text-white focus:border-[#22c55e] outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-300 font-semibold mb-1">Subtítulo / Ramo</label>
                      <input
                        type="text"
                        placeholder="Ex: Loja de Roupas Femininas"
                        value={newProject.subtitle}
                        onChange={(e) => setNewProject({ ...newProject, subtitle: e.target.value })}
                        className="w-full bg-[#050b07] border border-slate-700 rounded-xl p-2.5 text-white focus:border-[#22c55e] outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-300 font-semibold mb-1">Link do Site Real (URL)</label>
                      <input
                        type="url"
                        placeholder="https://exemplo.vercel.app"
                        value={newProject.url}
                        onChange={(e) => setNewProject({ ...newProject, url: e.target.value })}
                        className="w-full bg-[#050b07] border border-slate-700 rounded-xl p-2.5 text-white focus:border-[#22c55e] outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-300 font-semibold mb-1">Categoria</label>
                      <select
                        value={newProject.category}
                        onChange={(e: any) =>
                          setNewProject({
                            ...newProject,
                            category: e.target.value,
                            categoryLabel: e.target.options[e.target.selectedIndex].text,
                          })
                        }
                        className="w-full bg-[#050b07] border border-slate-700 rounded-xl p-2.5 text-white focus:border-[#22c55e] outline-none"
                      >
                        <option value="confeitaria">Confeitaria & Salgados</option>
                        <option value="padaria">Padaria & Cafeteria</option>
                        <option value="petshop">PetShop & Veterinária</option>
                        <option value="beleza">Salão de Beleza & Estética</option>
                        <option value="construcao">Materiais de Construção</option>
                        <option value="todos">Outro Ramo</option>
                      </select>
                    </div>
                    <div className="sm:col-span-2">
                      <label className="block text-slate-300 font-semibold mb-1">Descrição</label>
                      <textarea
                        rows={2}
                        placeholder="Descreva o que o site faz e os diferenciais..."
                        value={newProject.description}
                        onChange={(e) => setNewProject({ ...newProject, description: e.target.value })}
                        className="w-full bg-[#050b07] border border-slate-700 rounded-xl p-2.5 text-white focus:border-[#22c55e] outline-none"
                      />
                    </div>
                  </div>
                  <div className="flex justify-end gap-2 pt-2">
                    <button
                      onClick={() => setIsAddingProject(false)}
                      className="px-4 py-2 text-xs font-semibold text-slate-400 hover:text-white"
                    >
                      Cancelar
                    </button>
                    <button
                      onClick={handleCreateProject}
                      className="px-5 py-2 bg-[#22c55e] text-black font-extrabold text-xs rounded-xl shadow hover:bg-[#20b857]"
                    >
                      Salvar Projeto
                    </button>
                  </div>
                </div>
              )}

              {/* Projects Table / Cards */}
              <div className="space-y-3">
                {projects.map((proj) => (
                  <div
                    key={proj.id}
                    className="p-4 bg-[#0b1812] border border-[#22c55e]/25 rounded-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
                  >
                    <div className="flex items-center gap-3.5">
                      <div className="w-12 h-12 rounded-xl bg-slate-900 border border-slate-700 overflow-hidden shrink-0 relative">
                        {/* eslint-disable-next-line @next/next/no-img-element */}
                        <img
                          src={proj.image}
                          alt={proj.title}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="font-bold text-sm text-white">{proj.title}</h4>
                          <span className="text-[10px] bg-[#163826] text-[#4ade80] px-2 py-0.5 rounded-full border border-[#22c55e]/30">
                            {proj.categoryLabel}
                          </span>
                        </div>
                        <p className="text-xs text-slate-400 mt-0.5">{proj.subtitle}</p>
                        <a
                          href={proj.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-[11px] text-[#22c55e] hover:underline flex items-center gap-1 mt-1 font-mono"
                        >
                          <span>{proj.url}</span>
                          <ExternalLink className="w-3 h-3" />
                        </a>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 self-end sm:self-center">
                      <a
                        href={proj.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-xs text-slate-200 border border-slate-700 flex items-center gap-1"
                      >
                        <Globe className="w-3 h-3" />
                        <span>Acessar</span>
                      </a>
                      <button
                        onClick={() => handleDeleteProject(proj.id)}
                        className="p-2 text-red-400 hover:text-red-300 hover:bg-red-500/10 rounded-xl transition"
                        title="Excluir projeto"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 2: WHATSAPP */}
          {activeTab === 'whatsapp' && (
            <form onSubmit={handleSaveConfig} className="space-y-6 max-w-xl">
              <div className="bg-[#0b1711] border border-[#22c55e]/30 p-5 rounded-2xl space-y-4">
                <h3 className="text-sm font-black text-white flex items-center gap-2">
                  <Phone className="w-4 h-4 text-[#22c55e]" />
                  Configuração do WhatsApp Principal
                </h3>
                <p className="text-xs text-slate-300">
                  Este é o número que receberá todas as conversões de clientes do site, dos botões de ação e dos QR Codes.
                </p>

                <div>
                  <label className="block text-xs font-bold text-slate-200 mb-1">
                    Número do WhatsApp (com DDD)
                  </label>
                  <input
                    type="text"
                    value={phoneInput}
                    onChange={(e) => setPhoneInput(e.target.value)}
                    placeholder="22981728574"
                    className="w-full bg-[#050b07] border border-slate-700 focus:border-[#22c55e] rounded-xl p-3 text-white text-sm font-mono outline-none"
                  />
                  <span className="text-[11px] text-slate-400 mt-1 block">
                    Atual: <strong>{siteConfig.phoneRaw}</strong> (Configurado para o DDD 22)
                  </span>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-200 mb-1">
                    Formato de Exibição Visual
                  </label>
                  <input
                    type="text"
                    value={phoneFormattedInput}
                    onChange={(e) => setPhoneFormattedInput(e.target.value)}
                    placeholder="(22) 98172-8574"
                    className="w-full bg-[#050b07] border border-slate-700 focus:border-[#22c55e] rounded-xl p-3 text-white text-sm outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-200 mb-1">
                    Mensagem Padrão de Abertura
                  </label>
                  <textarea
                    rows={3}
                    value={messageInput}
                    onChange={(e) => setMessageInput(e.target.value)}
                    className="w-full bg-[#050b07] border border-slate-700 focus:border-[#22c55e] rounded-xl p-3 text-white text-xs outline-none"
                  />
                  <span className="text-[11px] text-slate-400 mt-1 block">
                    O cliente enviará esta mensagem quando clicar no botão ou escanear o QR Code.
                  </span>
                </div>

                <div className="pt-2 flex items-center justify-between">
                  <a
                    href={getWhatsAppUrl(phoneInput, messageInput)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-xs text-[#22c55e] hover:underline flex items-center gap-1 font-semibold"
                  >
                    <span>Testar no WhatsApp</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>

                  <button
                    type="submit"
                    className="flex items-center gap-2 bg-[#22c55e] hover:bg-[#20b857] text-black font-extrabold text-xs px-6 py-2.5 rounded-xl shadow-lg transition"
                  >
                    <Save className="w-3.5 h-3.5" />
                    <span>Salvar Configurações</span>
                  </button>
                </div>

                {saveSuccess && (
                  <div className="p-3 rounded-xl bg-[#22c55e]/20 border border-[#22c55e]/40 text-[#4ade80] text-xs font-bold flex items-center gap-2">
                    <Check className="w-4 h-4" />
                    <span>Configurações salvas com sucesso! O site já está atualizado.</span>
                  </div>
                )}
              </div>
            </form>
          )}

          {/* TAB 3: QR CODE GENERATOR */}
          {activeTab === 'qrcode' && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-start">
                <div className="bg-[#0b1711] border border-[#22c55e]/30 p-5 rounded-2xl space-y-4">
                  <h3 className="text-sm font-black text-white flex items-center gap-2">
                    <QrCode className="w-4 h-4 text-[#22c55e]" />
                    Gerador de QR Code em Alta Resolução
                  </h3>
                  <p className="text-xs text-slate-300">
                    Gere e baixe a imagem do QR Code para colocar em cartões de visita, panfletos ou em posts e stories do Facebook/Instagram.
                  </p>

                  <div>
                    <label className="block text-xs font-bold text-slate-200 mb-1">
                      Destino do QR Code (Link ou WhatsApp)
                    </label>
                    <input
                      type="text"
                      value={qrText}
                      onChange={(e) => {
                        setQrText(e.target.value);
                        QRCode.toDataURL(e.target.value, { width: 500, margin: 2 }).then((url) =>
                          setGeneratedQrData(url)
                        );
                      }}
                      className="w-full bg-[#050b07] border border-slate-700 rounded-xl p-3 text-white text-xs font-mono outline-none"
                    />
                  </div>

                  <div className="p-3 rounded-xl bg-[#14281e] border border-[#22c55e]/30 text-xs text-slate-200 space-y-1">
                    <span className="font-bold text-[#4ade80] block">Vantagens do QR Code:</span>
                    <p>• O cliente aponta a câmera do celular e abre o seu WhatsApp instantaneamente.</p>
                    <p>• Elimina o erro de digitação do telefone 22981728574.</p>
                    <p>• Aumenta a taxa de conversão em até 40% em materiais impressos e telas.</p>
                  </div>

                  <button
                    onClick={handleDownloadQr}
                    className="w-full flex items-center justify-center gap-2 bg-[#22c55e] hover:bg-[#20b857] text-black font-extrabold text-xs py-3 rounded-xl shadow transition"
                  >
                    <Download className="w-4 h-4" />
                    <span>Baixar Imagem do QR Code (PNG)</span>
                  </button>
                </div>

                {/* QR Code Preview Box */}
                <div className="flex flex-col items-center justify-center p-6 bg-white rounded-2xl shadow-xl text-center">
                  <div className="w-64 h-64 relative flex items-center justify-center">
                    {generatedQrData ? (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img
                        src={generatedQrData}
                        alt="QR Code WhatsApp Jeferson Ribeiro"
                        className="w-full h-full object-contain"
                      />
                    ) : (
                      <div className="w-full h-full bg-slate-100 animate-pulse" />
                    )}
                  </div>
                  <span className="text-xs font-bold text-slate-900 mt-3">
                    Jeferson Ribeiro - Criador de Sites
                  </span>
                  <span className="text-xs text-slate-600 font-mono">
                    {siteConfig.phoneFormatted}
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: LEADS & CLIQUES */}
          {activeTab === 'leads' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between bg-[#0b1711] p-4 rounded-2xl border border-[#22c55e]/30">
                <div>
                  <h3 className="text-sm font-black text-white">
                    Histórico de Cliques de Conversão
                  </h3>
                  <p className="text-xs text-slate-300">
                    Acompanhe quais botões e projetos estão gerando mais contatos no WhatsApp.
                  </p>
                </div>
                <span className="bg-[#22c55e] text-black font-extrabold text-xs px-3 py-1 rounded-full">
                  {leadList.length} Cliques Registrados
                </span>
              </div>

              {leadList.length === 0 ? (
                <div className="text-center py-12 text-slate-400 text-xs bg-[#0b1711] rounded-2xl border border-slate-800">
                  Nenhum clique registrado ainda nesta sessão. Conforme os visitantes clicarem nos botões de WhatsApp ou no QR Code, eles aparecerão aqui.
                </div>
              ) : (
                <div className="space-y-2 max-h-96 overflow-y-auto">
                  {leadList.map((lead) => (
                    <div
                      key={lead.id}
                      className="p-3 rounded-xl bg-[#0b1711] border border-slate-800 flex items-center justify-between text-xs"
                    >
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-[#22c55e]" />
                        <span className="font-semibold text-white">
                          {lead.projectTitle ? `Projeto: ${lead.projectTitle}` : `Ação: ${lead.source}`}
                        </span>
                      </div>
                      <span className="text-slate-400 font-mono text-[11px]">
                        {new Date(lead.timestamp).toLocaleTimeString('pt-BR')} -{' '}
                        {new Date(lead.timestamp).toLocaleDateString('pt-BR')}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 5: SIMULADOR FACEBOOK ADS */}
          {activeTab === 'facebook' && (
            <div className="space-y-6">
              <div className="bg-[#0b1711] p-4 rounded-2xl border border-[#22c55e]/30">
                <h3 className="text-sm font-black text-white">
                  Prévia para Facebook Ads e Tráfego Direto (PDR)
                </h3>
                <p className="text-xs text-slate-300">
                  Esta página foi desenhada para carregar instantaneamente quando alguém clica no seu anúncio do Facebook, Instagram ou link na bio.
                </p>
              </div>

              <div className="max-w-md mx-auto bg-[#18191a] border border-slate-700 rounded-2xl p-4 shadow-2xl text-slate-200 text-xs">
                {/* Facebook Post Header */}
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-10 h-10 rounded-full bg-[#22c55e] text-black font-black flex items-center justify-center text-sm">
                    JR
                  </div>
                  <div>
                    <span className="font-bold text-white block">
                      Jeferson Ribeiro - Criador de Sites
                    </span>
                    <span className="text-[10px] text-slate-400">Patrocinado · 🌐</span>
                  </div>
                </div>

                <p className="mb-3 text-slate-300 leading-relaxed">
                  Precisa de um site profissional para o seu negócio? Desenvolvo sites modernos, rápidos e com botão direto para seu WhatsApp! Conheça meus projetos e peça um orçamento agora mesmo 👇
                </p>

                {/* Facebook Card Image */}
                <div className="rounded-xl overflow-hidden border border-slate-700 bg-black mb-3">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src="/images/hero_devices_showcase.jpg"
                    alt="Prévia Facebook"
                    className="w-full aspect-[16/9] object-cover"
                  />
                  <div className="p-3 bg-[#242526] flex items-center justify-between">
                    <div>
                      <span className="text-[10px] text-slate-400 uppercase tracking-wide block">
                        PORTFÓLIO PROFISSIONAL
                      </span>
                      <span className="font-bold text-white text-sm block">
                        Jeferson Ribeiro | Criador de Sites
                      </span>
                      <span className="text-[11px] text-slate-300">
                        Clique e fale direto no WhatsApp: (22) 98172-8574
                      </span>
                    </div>
                    <span className="bg-[#22c55e] text-black font-extrabold px-3 py-1.5 rounded-lg text-xs shrink-0">
                      Saiba Mais
                    </span>
                  </div>
                </div>

                <div className="flex items-center justify-around border-t border-slate-700 pt-2 text-slate-400 font-semibold text-[11px]">
                  <span>👍 Curtir</span>
                  <span>💬 Comentar</span>
                  <span>↗️ Compartilhar</span>
                </div>
              </div>
            </div>
          )}

          {/* TAB 6: AVALIAÇÕES & COMENTÁRIOS DOS CLIENTES */}
          {activeTab === 'avaliacoes' && (
            <div className="space-y-6">
              {/* Header card with action buttons */}
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-[#0d2117] p-5 rounded-2xl border border-[#22c55e]/30">
                <div>
                  <h3 className="text-base font-black text-white flex items-center gap-2">
                    <Star className="w-4 h-4 text-[#fbbf24] fill-[#fbbf24]" />
                    Gestão de Depoimentos e Avaliações de Clientes
                  </h3>
                  <p className="text-xs text-slate-300 mt-1">
                    Visualize os comentários deixados pelos clientes no site ou adicione novos depoimentos recebidos via WhatsApp.
                  </p>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    onClick={() => {
                      if (confirm('Deseja restaurar a lista inicial de depoimentos recomendados?')) {
                        onUpdateTestimonials(TESTIMONIALS_DATA);
                      }
                    }}
                    className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition"
                    title="Restaurar originais"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>Restaurar Originais</span>
                  </button>

                  <button
                    onClick={() => setIsAddingReview(!isAddingReview)}
                    className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#22c55e] hover:bg-[#1ea750] text-black text-xs font-black transition shadow-md shadow-[#22c55e]/20"
                  >
                    <Plus className="w-4 h-4" />
                    <span>{isAddingReview ? 'Fechar Formulário' : 'Novo Depoimento'}</span>
                  </button>
                </div>
              </div>

              {/* Form to manually add a review */}
              {isAddingReview && (
                <div className="bg-[#0b1711] border-2 border-[#22c55e]/40 p-5 rounded-2xl space-y-4 animate-fadeIn">
                  <h4 className="text-sm font-black text-white flex items-center gap-2">
                    <MessageSquare className="w-4 h-4 text-[#22c55e]" />
                    Cadastrar Depoimento de Cliente Manualmente
                  </h4>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-slate-200 mb-1">
                        Nome do Cliente *
                      </label>
                      <input
                        type="text"
                        value={newReviewForm.name}
                        onChange={(e) => setNewReviewForm({ ...newReviewForm, name: e.target.value })}
                        placeholder="Ex: Marcos Vinicius"
                        className="w-full bg-[#050b07] border border-slate-700 rounded-xl p-2.5 text-white text-xs outline-none focus:border-[#22c55e]"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-200 mb-1">
                        Empresa / Negócio *
                      </label>
                      <input
                        type="text"
                        value={newReviewForm.company}
                        onChange={(e) => setNewReviewForm({ ...newReviewForm, company: e.target.value })}
                        placeholder="Ex: Pizzaria Forno Nobre"
                        className="w-full bg-[#050b07] border border-slate-700 rounded-xl p-2.5 text-white text-xs outline-none focus:border-[#22c55e]"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-200 mb-1">
                        Cargo / Função
                      </label>
                      <input
                        type="text"
                        value={newReviewForm.role}
                        onChange={(e) => setNewReviewForm({ ...newReviewForm, role: e.target.value })}
                        placeholder="Ex: Proprietário"
                        className="w-full bg-[#050b07] border border-slate-700 rounded-xl p-2.5 text-white text-xs outline-none focus:border-[#22c55e]"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-slate-200 mb-1">
                        Link do Site Criado (Opcional)
                      </label>
                      <input
                        type="text"
                        value={newReviewForm.websiteUrl}
                        onChange={(e) => setNewReviewForm({ ...newReviewForm, websiteUrl: e.target.value })}
                        placeholder="https://exemplo.com"
                        className="w-full bg-[#050b07] border border-slate-700 rounded-xl p-2.5 text-white text-xs outline-none focus:border-[#22c55e]"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-200 mb-1">
                        Classificação em Estrelas
                      </label>
                      <select
                        value={newReviewForm.stars}
                        onChange={(e) => setNewReviewForm({ ...newReviewForm, stars: Number(e.target.value) })}
                        className="w-full bg-[#050b07] border border-slate-700 rounded-xl p-2.5 text-white text-xs outline-none focus:border-[#22c55e]"
                      >
                        <option value={5}>⭐⭐⭐⭐⭐ 5 Estrelas (Excelente)</option>
                        <option value={4}>⭐⭐⭐⭐ 4 Estrelas (Muito Bom)</option>
                        <option value={3}>⭐⭐⭐ 3 Estrelas (Bom)</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-200 mb-1">
                        URL da Foto do Cliente
                      </label>
                      <input
                        type="text"
                        value={newReviewForm.avatar}
                        onChange={(e) => setNewReviewForm({ ...newReviewForm, avatar: e.target.value })}
                        placeholder="https://images.unsplash.com/..."
                        className="w-full bg-[#050b07] border border-slate-700 rounded-xl p-2.5 text-white text-xs outline-none focus:border-[#22c55e]"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-200 mb-1">
                      Comentário / Depoimento *
                    </label>
                    <textarea
                      rows={3}
                      value={newReviewForm.text}
                      onChange={(e) => setNewReviewForm({ ...newReviewForm, text: e.target.value })}
                      placeholder="Ex: O site ficou sensacional, muito rápido e atrativo! Os clientes elogiaram bastante..."
                      className="w-full bg-[#050b07] border border-slate-700 rounded-xl p-2.5 text-white text-xs outline-none focus:border-[#22c55e] resize-none"
                    />
                  </div>

                  <div className="flex justify-end gap-2">
                    <button
                      type="button"
                      onClick={() => setIsAddingReview(false)}
                      className="px-4 py-2 rounded-xl text-slate-400 hover:text-white text-xs"
                    >
                      Cancelar
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        if (!newReviewForm.name || !newReviewForm.company || !newReviewForm.text) {
                          alert('Por favor, preencha o nome, a empresa e o texto da avaliação.');
                          return;
                        }
                        const created: Testimonial = {
                          id: `admin-review-${Date.now()}`,
                          name: newReviewForm.name || 'Cliente',
                          role: newReviewForm.role || 'Cliente',
                          company: newReviewForm.company || 'Empresa',
                          avatar: newReviewForm.avatar || 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&auto=format&fit=crop&q=80',
                          stars: newReviewForm.stars || 5,
                          text: `“${newReviewForm.text.replace(/^["“]+|["”]+$/g, '')}”`,
                          verified: true,
                          date: 'Publicado pelo Admin',
                          websiteUrl: newReviewForm.websiteUrl ? (newReviewForm.websiteUrl.startsWith('http') ? newReviewForm.websiteUrl : `https://${newReviewForm.websiteUrl}`) : undefined,
                          likes: 5,
                        };
                        onUpdateTestimonials([created, ...testimonials]);
                        setIsAddingReview(false);
                        setNewReviewForm({
                          name: '',
                          role: 'Cliente',
                          company: '',
                          stars: 5,
                          text: '',
                          websiteUrl: '',
                          avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&auto=format&fit=crop&q=80',
                        });
                      }}
                      className="px-5 py-2 rounded-xl bg-[#22c55e] hover:bg-[#1ea750] text-black font-black text-xs transition"
                    >
                      Salvar Avaliação
                    </button>
                  </div>
                </div>
              )}

              {/* Reviews List */}
              <div className="space-y-3">
                {testimonials.map((item) => (
                  <div
                    key={item.id}
                    className="p-4 rounded-2xl bg-[#0b1711] border border-slate-800 hover:border-[#22c55e]/40 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 transition"
                  >
                    <div className="flex items-start gap-3.5">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img
                        src={item.avatar}
                        alt={item.name}
                        className="w-12 h-12 rounded-full object-cover border-2 border-[#22c55e]/40 shrink-0"
                      />
                      <div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-black text-white text-sm">
                            {item.name}
                          </span>
                          <span className="text-xs text-[#4ade80] font-semibold">
                            • {item.company} ({item.role})
                          </span>
                          <div className="flex items-center gap-0.5">
                            {Array.from({ length: item.stars }).map((_, i) => (
                              <Star key={i} className="w-3 h-3 fill-[#fbbf24] text-[#fbbf24]" />
                            ))}
                          </div>
                        </div>

                        <p className="text-xs text-slate-300 italic mt-1 leading-relaxed">
                          {item.text}
                        </p>

                        <div className="flex items-center gap-3 text-[11px] text-slate-400 mt-2 flex-wrap">
                          <span>{item.date || 'Cliente Verificado'}</span>
                          {item.websiteUrl && (
                            <a
                              href={item.websiteUrl}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-[#22c55e] hover:underline flex items-center gap-1"
                            >
                              <span>Site: {item.websiteUrl}</span>
                              <ExternalLink className="w-3 h-3" />
                            </a>
                          )}
                          <span>👍 {item.likes || 0} curtidas</span>
                        </div>
                      </div>
                    </div>

                    <div className="shrink-0 flex items-center gap-2 self-end md:self-center">
                      <button
                        onClick={() => {
                          if (confirm(`Deseja remover a avaliação de "${item.name}"?`)) {
                            onUpdateTestimonials(testimonials.filter((t) => t.id !== item.id));
                          }
                        }}
                        className="p-2 rounded-xl bg-red-950/40 hover:bg-red-900/60 text-red-300 border border-red-900/50 transition flex items-center gap-1 text-xs"
                        title="Remover avaliação"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>Remover</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Admin Footer */}
        <div className="px-6 py-3 bg-[#050b07] border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
          <span>Jeferson Ribeiro • WhatsApp: {siteConfig.phoneFormatted}</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded-xl transition"
          >
            Fechar Painel
          </button>
        </div>
      </div>
    </div>
  );
}
