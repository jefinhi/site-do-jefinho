'use client';

interface BrandLogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg';
}

export function BrandLogo({ className = '', size = 'md' }: BrandLogoProps) {
  const isSm = size === 'sm';
  const isLg = size === 'lg';

  return (
    <div className={`flex items-center gap-2.5 select-none ${className}`}>
      {/* Stylized JR Icon */}
      <div className="relative flex items-center justify-center">
        <svg
          viewBox="0 0 48 48"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className={`${isSm ? 'w-8 h-8' : isLg ? 'w-12 h-12' : 'w-10 h-10'} drop-shadow-[0_0_12px_rgba(34,197,94,0.4)]`}
        >
          {/* Outer glowing dynamic curve */}
          <path
            d="M8 24C8 14 16 6 27 6C33 6 38 9 41 14"
            stroke="#22c55e"
            strokeWidth="3.5"
            strokeLinecap="round"
          />
          <path
            d="M40 24C40 34 32 42 21 42C15 42 10 39 7 34"
            stroke="#16a34a"
            strokeWidth="3.5"
            strokeLinecap="round"
          />
          {/* Monogram J and R */}
          <path
            d="M17 17V27C17 30 14.5 32 11.5 31"
            stroke="#ffffff"
            strokeWidth="3.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <path
            d="M23 16H31C34 16 36 18 36 21C36 24 34 26 31 26H23V32M29 26L36 33"
            stroke="#22c55e"
            strokeWidth="3.5"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          <circle cx="17" cy="12" r="2" fill="#22c55e" />
        </svg>
      </div>

      {/* Brand Name Typography */}
      <div className="flex flex-col leading-none">
        <span
          className={`font-black tracking-tight text-white ${
            isSm ? 'text-base' : isLg ? 'text-2xl' : 'text-xl'
          }`}
        >
          Jeferson <span className="text-[#22c55e]">Ribeiro</span>
        </span>
        <div className="flex items-center gap-1.5 mt-0.5">
          <span
            className={`font-bold tracking-widest text-slate-300 uppercase ${
              isSm ? 'text-[8px]' : isLg ? 'text-xs' : 'text-[10px]'
            }`}
          >
            CRIADOR
          </span>
          <span
            className={`bg-[#22c55e]/20 border border-[#22c55e]/40 text-[#22c55e] font-extrabold tracking-wider px-1.5 py-0.2 rounded uppercase ${
              isSm ? 'text-[8px]' : isLg ? 'text-xs' : 'text-[9px]'
            }`}
          >
            DE SITES
          </span>
        </div>
      </div>
    </div>
  );
}
