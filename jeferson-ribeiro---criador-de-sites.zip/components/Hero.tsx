'use client';

import { useState, useEffect } from 'react';
import Image from 'next/image';
import { QRCodeCard } from './QRCodeCard';
import {
  Smartphone,
  ShieldCheck,
  TrendingUp,
  Settings,
  MessageCircle,
  UserCheck,
  ChevronRight,
  ChevronLeft,
  Sparkles,
  ExternalLink,
  Laptop,
  Pause,
  Play,
  Globe,
  Lock,
  RefreshCw,
  Eye,
} from 'lucide-react';
import { getWhatsAppUrl, trackLeadClick } from '@/lib/whatsapp-utils';
import { Project, INITIAL_PROJECTS } from '@/lib/portfolio-data';

interface HeroProps {
  phoneRaw: string;
  phoneFormatted: string;
  projects?: Project[];
}

export function Hero({ phoneRaw, phoneFormatted, projects = INITIAL_PROJECTS }: HeroProps) {
  // Use projects with images or fallback to initial
  const baseList = projects && projects.length > 0 ? projects : INITIAL_PROJECTS;

  // Add the high-res desktop open website view to the rotation
  const showcaseList = [
    ...baseList,
    {
      id: 'open-web-desktop',
      title: 'Plataforma Corporativa & Negócios',
      subtitle: 'Estrutura completa com catálogo e conversão',
      category: 'corporativo',
      categoryLabel: 'Portal & E-commerce',
      description: 'Site corporativo de alta performance com design moderno e interface fluida.',
      url: 'https://jeferson-ribeiro-sites.vercel.app/',
      image: '/images/open_website_bg.jpg',
      tags: ['Desktop View', 'Alta Performance', 'Design Premium'],
      features: ['Interface Moderna', 'Navegação Ágil'],
      deliverables: ['Website Responsivo'],
      client: 'Empresas & Negócios',
      status: 'online' as const,
    },
  ];

  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [bgTransparency, setBgTransparency] = useState<number>(35); // 20%, 35%, 50%

  // Auto-rotate every 4.2 seconds
  useEffect(() => {
    if (isPaused || showcaseList.length <= 1) return;

    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % showcaseList.length);
    }, 4200);

    return () => clearInterval(timer);
  }, [isPaused, showcaseList.length]);

  const currentProject = showcaseList[currentIndex] || showcaseList[0];

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev - 1 + showcaseList.length) % showcaseList.length);
  };

  const handleNext = () => {
    setCurrentIndex((prev) => (prev + 1) % showcaseList.length);
  };

  const whatsappUrl = getWhatsAppUrl(
    phoneRaw,
    'Olá Jeferson! Vi sua página e quero solicitar um orçamento para meu site com atendimento prioritário.'
  );

  const benefits = [
    {
      icon: Smartphone,
      text: 'Sites modernos e responsivos',
      sub: '(celular e computador)',
    },
    {
      icon: ShieldCheck,
      text: 'Design profissional',
      sub: 'com foco em resultados',
    },
    {
      icon: TrendingUp,
      text: 'Mais visibilidade',
      sub: 'no Google e no seu bairro',
    },
    {
      icon: Settings,
      text: 'Suporte',
      sub: 'após a entrega',
    },
    {
      icon: MessageCircle,
      text: 'Integração com WhatsApp',
      sub: 'para receber mais clientes',
    },
    {
      icon: UserCheck,
      text: 'Atendimento',
      sub: 'personalizado',
    },
  ];

  // Clean domain display for the background open browser URL bar
  const cleanUrl = currentProject.url
    ? currentProject.url.replace(/^https?:\/\//, '').replace(/\/$/, '')
    : 'meusite.com.br';

  return (
    <section
      id="inicio"
      className="relative min-h-screen pt-28 pb-16 lg:pt-36 lg:pb-24 overflow-hidden bg-radial from-[#0f281b] via-[#091510] to-[#060c09]"
    >
      {/* CAMADA DE FUNDO TRANSLÚCIDA: SITE REAL ABERTO NO NAVEGADOR COM TRANSPARÊNCIA */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden z-0 flex items-center justify-center">
        {/* Janela de Navegador Desktop Gigante no Fundo */}
        <div className="relative w-[98vw] max-w-[1600px] h-[92vh] -top-2 rounded-2xl border border-[#22c55e]/25 shadow-[0_0_90px_rgba(0,0,0,0.85)] bg-[#050c08]/90 overflow-hidden flex flex-col">
          
          {/* Top Browser Bar of the Open Website */}
          <div className="h-10 px-4 bg-[#08170f]/95 border-b border-[#22c55e]/25 flex items-center justify-between text-xs select-none backdrop-blur-md">
            {/* Window control dots */}
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded-full bg-red-500/80 inline-block border border-red-600/40" />
                <span className="w-3 h-3 rounded-full bg-amber-500/80 inline-block border border-amber-600/40" />
                <span className="w-3 h-3 rounded-full bg-emerald-500/80 inline-block border border-emerald-600/40" />
              </div>
              {/* Active Tab of the Open Website */}
              <div className="ml-2 hidden sm:flex items-center gap-2 px-3.5 py-1 rounded-t-xl bg-[#0e271a] border-t border-x border-[#22c55e]/30 text-slate-100 text-[11px] font-semibold shadow-sm">
                <Globe className="w-3.5 h-3.5 text-[#22c55e]" />
                <span className="max-w-[220px] truncate">{currentProject.title} — Site Aberto</span>
                <span className="text-[10px] text-slate-400 font-normal">×</span>
              </div>
            </div>

            {/* URL Address Bar with SSL Lock and Domain */}
            <div className="flex-1 max-w-xl mx-2 sm:mx-6 flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#040a06]/90 border border-[#22c55e]/30 text-slate-400 text-[11px] font-mono shadow-inner">
              <Lock className="w-3.5 h-3.5 text-[#22c55e] shrink-0" />
              <span className="text-[#4ade80] font-bold">https://</span>
              <span className="text-slate-100 truncate">{cleanUrl}</span>
              <span className="ml-auto text-[9px] text-black font-sans font-black bg-[#22c55e] px-1.5 py-0.5 rounded shadow-sm">
                SITE ABERTO
              </span>
            </div>

            {/* Status indicator */}
            <div className="flex items-center gap-2 text-[11px] text-slate-300">
              <RefreshCw className="w-3 h-3 text-[#22c55e] animate-spin" style={{ animationDuration: '6s' }} />
              <span className="hidden md:inline font-mono text-[10px] text-slate-400">200 OK • 0.3s</span>
            </div>
          </div>

          {/* Webpage Viewport: Real Open Website with crisp resolution & transparency */}
          <div className="relative flex-1 w-full overflow-hidden bg-[#050b07]">
            {showcaseList.map((proj, idx) => {
              const isActive = idx === currentIndex;
              return (
                <div
                  key={`bg-open-site-${proj.id}`}
                  className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${
                    isActive ? 'opacity-100' : 'opacity-0 pointer-events-none'
                  }`}
                >
                  {/* Real Open Website Image (No blur! Completely crisp and visible) */}
                  <Image
                    src={proj.image}
                    alt={proj.title}
                    fill
                    className="object-cover object-top filter contrast-110 brightness-95"
                    priority={idx <= 1}
                  />
                </div>
              );
            })}

            {/* Transparent Scrim / Overlay: Allows the open website to remain clearly visible while keeping text 100% legible */}
            <div
              className={`absolute inset-0 transition-all duration-500 pointer-events-none ${
                bgTransparency === 20
                  ? 'bg-gradient-to-r from-[#060c09]/92 via-[#060c09]/82 to-[#060c09]/90'
                  : bgTransparency === 50
                  ? 'bg-gradient-to-r from-[#060c09]/72 via-[#060c09]/50 to-[#060c09]/68'
                  : 'bg-gradient-to-r from-[#060c09]/84 via-[#060c09]/68 to-[#060c09]/80'
              }`}
            />

            {/* Top & Bottom dark fades for seamless blending with the navbar and next section */}
            <div className="absolute inset-x-0 top-0 h-32 bg-gradient-to-b from-[#060c09] to-transparent pointer-events-none" />
            <div className="absolute inset-x-0 bottom-0 h-40 bg-gradient-to-t from-[#060c09] via-[#060c09]/90 to-transparent pointer-events-none" />
          </div>
        </div>
      </div>

      {/* Background ambient light effects */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[700px] h-[500px] bg-[#22c55e]/15 blur-[140px] rounded-full pointer-events-none z-0" />
      <div className="absolute -top-10 -right-10 w-96 h-96 bg-[#16a34a]/10 blur-[100px] rounded-full pointer-events-none z-0" />

      {/* Subtle geometric grid pattern */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#1f3d2d15_1px,transparent_1px),linear-gradient(to_bottom,#1f3d2d15_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_40%,#000_70%,transparent_100%)] pointer-events-none z-0" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-center">
          {/* Left Column: Copy, Value Props, CTA, QR Code */}
          <div className="lg:col-span-7 flex flex-col items-start text-left">
            {/* Pill Badge */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#163323]/80 border border-[#22c55e]/40 text-[#4ade80] text-xs sm:text-sm font-semibold mb-5 shadow-[0_0_15px_rgba(34,197,94,0.15)] backdrop-blur-md">
              <span className="text-[#22c55e] font-mono font-bold">&lt;/&gt;</span>
              <span>Seu negócio online, mais perto dos seus clientes!</span>
            </div>

            {/* Main Headline */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black text-white tracking-tight leading-[1.08] mb-4">
              Jeferson <span className="text-[#22c55e] drop-shadow-[0_0_20px_rgba(34,197,94,0.5)]">Ribeiro</span>
              <br />
              <span className="text-white tracking-normal font-black">CRIADOR DE SITES</span>
            </h1>

            {/* Subheading */}
            <p className="text-lg sm:text-xl text-slate-300 font-normal leading-relaxed max-w-2xl mb-8">
              Sites <strong className="text-white font-semibold">modernos, rápidos e responsivos</strong>, feitos para valorizar o seu negócio e <strong className="text-[#4ade80] font-semibold">gerar mais resultados!</strong>
            </p>

            {/* Key Benefits Grid (2 Columns, 3 Rows) */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-4 w-full mb-8">
              {benefits.map((benefit, idx) => {
                const Icon = benefit.icon;
                return (
                  <div key={idx} className="flex items-start gap-3">
                    <div className="w-8 h-8 rounded-lg bg-[#163323]/90 border border-[#22c55e]/40 flex items-center justify-center shrink-0 text-[#22c55e] shadow-sm backdrop-blur-sm">
                      <Icon className="w-4 h-4" />
                    </div>
                    <div className="flex flex-col text-sm">
                      <span className="font-semibold text-slate-100 leading-snug">
                        {benefit.text}
                      </span>
                      <span className="text-xs text-slate-400">
                        {benefit.sub}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Call to Action and QR Code Card */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 w-full pt-2">
              {/* Main Glowing CTA Button */}
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => trackLeadClick('hero_solicite_agora_cta')}
                className="group relative flex items-center gap-4 bg-[#22c55e] hover:bg-[#20b857] text-black px-6 py-4 rounded-2xl shadow-[0_4px_25px_rgba(34,197,94,0.45)] transition-all transform hover:-translate-y-0.5 active:translate-y-0 text-left cursor-pointer"
              >
                <div className="w-11 h-11 bg-black text-[#22c55e] rounded-full flex items-center justify-center shrink-0 shadow-md group-hover:scale-110 transition-transform">
                  <MessageCircle className="w-6 h-6 fill-[#22c55e]" />
                </div>
                <div className="flex flex-col">
                  <span className="text-sm sm:text-base font-black tracking-tight leading-tight flex items-center gap-1">
                    SOLICITE SEU SITE AGORA
                    <ChevronRight className="w-4 h-4 stroke-[3] group-hover:translate-x-1 transition-transform" />
                  </span>
                  <span className="text-[11px] font-extrabold text-black/80 uppercase tracking-wider">
                    PELO WHATSAPP
                  </span>
                </div>
              </a>

              {/* Scannable QR Code Card */}
              <div className="shrink-0">
                <QRCodeCard
                  phoneRaw={phoneRaw}
                  phoneFormatted={phoneFormatted}
                  variant="hero"
                  label="Escaneie o QR Code e fale comigo!"
                />
              </div>
            </div>

            {/* Controle Interativo do Fundo Translúcido (Site Aberto no Fundo) */}
            <div className="mt-7 w-full p-3 rounded-2xl bg-[#091810]/80 border border-[#22c55e]/30 shadow-lg backdrop-blur-md flex flex-wrap items-center justify-between gap-3 text-xs">
              <div className="flex items-center gap-2 min-w-0">
                <div className="w-2.5 h-2.5 rounded-full bg-[#22c55e] animate-ping shrink-0" />
                <Globe className="w-4 h-4 text-[#22c55e] shrink-0" />
                <div className="min-w-0">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className="text-[11px] text-slate-400 font-medium">Fundo transparente:</span>
                    <span className="text-xs font-black text-white truncate">{currentProject.title}</span>
                    <span className="text-[10px] text-[#4ade80] font-mono font-semibold">({cleanUrl})</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2 flex-wrap ml-auto">
                {/* Transparency level options */}
                <div className="flex items-center gap-1 bg-[#050e08] p-1 rounded-xl border border-slate-800">
                  <Eye className="w-3 h-3 text-slate-400 ml-1" />
                  {[
                    { label: '20% Suave', val: 20 },
                    { label: '35% Médio', val: 35 },
                    { label: '50% Nítido', val: 50 },
                  ].map((level) => (
                    <button
                      key={level.val}
                      onClick={() => setBgTransparency(level.val)}
                      className={`px-2 py-0.5 rounded-lg text-[10px] font-bold transition ${
                        bgTransparency === level.val
                          ? 'bg-[#22c55e] text-black shadow-sm'
                          : 'text-slate-400 hover:text-white'
                      }`}
                      title={`Definir visibilidade do site de fundo em ${level.label}`}
                    >
                      {level.label}
                    </button>
                  ))}
                </div>

                {/* Pause/Next controls */}
                <div className="flex items-center gap-1">
                  <button
                    onClick={handlePrev}
                    className="p-1.5 rounded-lg bg-[#0e2417] hover:bg-[#163323] text-slate-300 hover:text-white border border-[#22c55e]/30 transition"
                    title="Ver site anterior no fundo"
                    aria-label="Site anterior"
                  >
                    <ChevronLeft className="w-3.5 h-3.5" />
                  </button>

                  <button
                    onClick={() => setIsPaused(!isPaused)}
                    className="px-2.5 py-1 rounded-lg bg-[#0e2417] hover:bg-[#163323] text-slate-200 hover:text-white border border-[#22c55e]/30 transition text-[11px] font-semibold flex items-center gap-1"
                    title={isPaused ? 'Continuar alternância de sites' : 'Pausar no site atual'}
                  >
                    {isPaused ? <Play className="w-3 h-3 text-[#22c55e]" /> : <Pause className="w-3 h-3 text-amber-400" />}
                    <span>{isPaused ? 'Pausado' : 'Alternando'}</span>
                  </button>

                  <button
                    onClick={handleNext}
                    className="p-1.5 rounded-lg bg-[#0e2417] hover:bg-[#163323] text-slate-300 hover:text-white border border-[#22c55e]/30 transition"
                    title="Ver próximo site no fundo"
                    aria-label="Próximo site"
                  >
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Hero Showcase com transparência e alternância de sites */}
          <div
            className="lg:col-span-5 relative flex items-center justify-center mt-6 lg:mt-0"
            onMouseEnter={() => setIsPaused(true)}
            onMouseLeave={() => setIsPaused(false)}
          >
            {/* Ambient Backlight Glow */}
            <div className="absolute inset-0 bg-[#22c55e]/25 blur-[90px] rounded-full pointer-events-none" />

            {/* Floating Top Badge in script/modern style with glassmorphism */}
            <div className="absolute -top-6 sm:-top-8 -right-2 sm:right-2 z-30 bg-gradient-to-r from-[#163323]/95 to-[#0c1f14]/95 border border-[#22c55e]/60 text-white px-4 py-2 rounded-2xl shadow-[0_8px_30px_rgba(0,0,0,0.8)] flex items-center gap-2 rotate-2 backdrop-blur-md">
              <Sparkles className="w-4 h-4 text-[#22c55e]" />
              <span className="text-xs sm:text-sm font-bold italic tracking-wide text-slate-100">
                Mais que um site, é o <span className="text-[#22c55e] not-italic font-black">seu negócio</span> no digital!
              </span>
            </div>

            {/* Device Showcase Container com Transparência e Alternância */}
            <div className="relative z-10 w-full max-w-md sm:max-w-lg rounded-3xl overflow-hidden border-2 border-[#22c55e]/40 shadow-[0_20px_60px_rgba(0,0,0,0.9),0_0_40px_rgba(34,197,94,0.25)] bg-[#0c1912]/80 backdrop-blur-md group">
              
              {/* Browser bar com visual de navegador moderno e translúcido */}
              <div className="px-4 py-3 bg-[#06110a]/90 border-b border-[#22c55e]/25 flex items-center justify-between backdrop-blur-sm">
                <div className="flex items-center gap-1.5">
                  <div className="w-3 h-3 rounded-full bg-red-500/80" />
                  <div className="w-3 h-3 rounded-full bg-yellow-500/80" />
                  <div className="w-3 h-3 rounded-full bg-green-500/80" />
                  <span className="ml-2 text-[10px] text-slate-400 font-mono flex items-center gap-1">
                    <Laptop className="w-3 h-3 text-[#22c55e]" />
                    <span>preview-site.online</span>
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-[#163323] text-[#4ade80] text-[10px] font-semibold border border-[#22c55e]/30">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#22c55e] animate-pulse" />
                    Site no ar
                  </span>

                  {/* Pause / Play indicator */}
                  <button
                    onClick={() => setIsPaused(!isPaused)}
                    className="p-1 rounded text-slate-400 hover:text-white transition"
                    title={isPaused ? 'Retomar alternância automática' : 'Pausar'}
                    aria-label="Pausar ou despausar alternância"
                  >
                    {isPaused ? <Play className="w-3 h-3" /> : <Pause className="w-3 h-3" />}
                  </button>
                </div>
              </div>

              {/* Display Area: Stacked images with transparent crossfade transitions */}
              <div className="relative aspect-[16/10] w-full overflow-hidden bg-black">
                {showcaseList.map((item, idx) => {
                  const isActive = idx === currentIndex;
                  return (
                    <div
                      key={item.id}
                      className={`absolute inset-0 transition-all duration-1000 ease-in-out ${
                        isActive
                          ? 'opacity-100 scale-100 pointer-events-auto'
                          : 'opacity-0 scale-105 pointer-events-none'
                      }`}
                    >
                      <Image
                        src={item.image}
                        alt={item.title}
                        fill
                        className="object-cover"
                        priority={idx <= 1}
                      />
                      
                      {/* Gradiente sutil para garantir legibilidade dos textos flutuantes */}
                      <div className="absolute inset-0 bg-gradient-to-t from-[#060e0a]/95 via-transparent to-black/30" />

                      {/* Informações do site em exibição com transparência/glassmorphism */}
                      <div className="absolute bottom-3 left-3 right-3 p-3 rounded-xl bg-[#09150e]/85 border border-[#22c55e]/35 backdrop-blur-md shadow-lg flex items-center justify-between gap-3">
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-2 mb-0.5">
                            <span className="text-xs font-black text-white truncate">
                              {item.title}
                            </span>
                            <span className="px-2 py-0.5 rounded-md bg-[#22c55e]/20 text-[#4ade80] text-[10px] font-bold shrink-0">
                              {item.categoryLabel}
                            </span>
                          </div>
                          <p className="text-[11px] text-slate-300 truncate">
                            {item.subtitle}
                          </p>
                        </div>

                        {/* Botão para testar o site real */}
                        <a
                          href={item.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          onClick={() => trackLeadClick(`hero_preview_${item.id}`)}
                          className="shrink-0 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#22c55e] hover:bg-[#1ea750] text-black font-black text-xs transition shadow-sm hover:scale-105"
                          title="Abrir site oficial criado"
                        >
                          <span>Ver Online</span>
                          <ExternalLink className="w-3 h-3" />
                        </a>
                      </div>
                    </div>
                  );
                })}

                {/* Seta de navegação anterior */}
                <button
                  type="button"
                  onClick={handlePrev}
                  className="absolute left-2 top-1/2 -translate-y-1/2 z-20 w-8 h-8 rounded-full bg-black/60 hover:bg-[#22c55e] text-white hover:text-black border border-white/20 flex items-center justify-center transition-all opacity-0 group-hover:opacity-100 shadow-md"
                  aria-label="Site anterior"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>

                {/* Seta de navegação próxima */}
                <button
                  type="button"
                  onClick={handleNext}
                  className="absolute right-2 top-1/2 -translate-y-1/2 z-20 w-8 h-8 rounded-full bg-black/60 hover:bg-[#22c55e] text-white hover:text-black border border-white/20 flex items-center justify-center transition-all opacity-0 group-hover:opacity-100 shadow-md"
                  aria-label="Próximo site"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>

              {/* Barra inferior: Indicadores de cada site com transparência e troca interativa */}
              <div className="p-3 bg-[#09150e]/95 border-t border-[#22c55e]/25 flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-[#22c55e] animate-ping" />
                  <span className="text-[11px] font-semibold text-slate-300 truncate">
                    {currentProject.title} ({currentIndex + 1} de {showcaseList.length})
                  </span>
                </div>

                {/* Seletor de pontos / slides */}
                <div className="flex items-center gap-1.5">
                  {showcaseList.map((item, idx) => (
                    <button
                      key={item.id}
                      onClick={() => setCurrentIndex(idx)}
                      className={`h-2 rounded-full transition-all duration-300 ${
                        idx === currentIndex
                          ? 'w-6 bg-[#22c55e]'
                          : 'w-2 bg-slate-700 hover:bg-slate-500'
                      }`}
                      aria-label={`Ver site ${item.title}`}
                      title={item.title}
                    />
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

