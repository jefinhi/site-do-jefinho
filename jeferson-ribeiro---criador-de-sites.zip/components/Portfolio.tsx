'use client';

import { useState, useRef } from 'react';
import Image from 'next/image';
import { Project, INITIAL_PROJECTS } from '@/lib/portfolio-data';
import { ProjectModal } from './ProjectModal';
import {
  ChevronLeft,
  ChevronRight,
  ExternalLink,
  Eye,
  MessageCircle,
  Sparkles,
  ArrowUpRight,
  Layers,
} from 'lucide-react';
import { getWhatsAppUrl, trackLeadClick } from '@/lib/whatsapp-utils';

interface PortfolioProps {
  phoneRaw: string;
  phoneFormatted: string;
  projects?: Project[];
}

export function Portfolio({
  phoneRaw,
  phoneFormatted,
  projects = INITIAL_PROJECTS,
}: PortfolioProps) {
  const [selectedCategory, setSelectedCategory] = useState<string>('todos');
  const [activeProjectModal, setActiveProjectModal] = useState<Project | null>(null);
  const [currentIndex, setCurrentIndex] = useState(0);
  const scrollRef = useRef<HTMLDivElement>(null);

  const categories = [
    { id: 'todos', label: 'Todos os Projetos' },
    { id: 'confeitaria', label: 'Confeitaria' },
    { id: 'padaria', label: 'Padaria' },
    { id: 'petshop', label: 'PetShop' },
    { id: 'beleza', label: 'Salão de Beleza' },
    { id: 'construcao', label: 'Materiais de Construção' },
  ];

  const filteredProjects =
    selectedCategory === 'todos'
      ? projects
      : projects.filter((p) => p.category === selectedCategory);

  const handleScroll = (direction: 'left' | 'right') => {
    if (!scrollRef.current) return;
    const container = scrollRef.current;
    const cardWidth = 320; // approximate width of item + gap
    const scrollAmount = direction === 'left' ? -cardWidth : cardWidth;
    container.scrollBy({ left: scrollAmount, behavior: 'smooth' });

    if (direction === 'right') {
      setCurrentIndex((prev) => Math.min(prev + 1, filteredProjects.length - 1));
    } else {
      setCurrentIndex((prev) => Math.max(prev - 1, 0));
    }
  };

  return (
    <section
      id="portfolio"
      className="relative py-20 sm:py-28 bg-[#08120c] overflow-hidden"
    >
      {/* Background ambient lighting */}
      <div className="absolute top-1/3 right-0 w-[600px] h-[500px] bg-[#22c55e]/10 blur-[150px] rounded-full pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-[500px] h-[400px] bg-[#16a34a]/10 blur-[130px] rounded-full pointer-events-none" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Top Split Header matching image.png */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-end mb-12">
          {/* Left: Badge, Headline, Subheading */}
          <div className="lg:col-span-8">
            <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#163323] border border-[#22c55e]/40 text-[#4ade80] text-xs font-semibold mb-3">
              <span className="text-[#22c55e] font-mono font-bold">&lt;/&gt;</span>
              <span>PROJETOS QUE GERAM RESULTADOS</span>
            </div>

            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black text-white tracking-tight leading-tight mb-4">
              Mais que um site,
              <br />
              é um <span className="text-[#22c55e]">investimento no seu futuro!</span>
            </h2>

            <p className="text-base sm:text-lg text-slate-300 max-w-2xl leading-relaxed">
              Conheça alguns dos sites que já desenvolvi e veja como podemos levar o seu negócio para o próximo nível.
            </p>
          </div>

          {/* Right: CTA Button & Navigation Arrows */}
          <div className="lg:col-span-4 flex flex-col sm:flex-row lg:flex-col items-start lg:items-end justify-between gap-4">
            <a
              href="#portfolio-grid"
              className="inline-flex items-center gap-2 bg-[#22c55e] hover:bg-[#20b857] text-black font-extrabold text-sm px-6 py-3.5 rounded-full shadow-[0_0_20px_rgba(34,197,94,0.35)] transition-all transform hover:scale-105 active:scale-95"
            >
              <span>VER MEU PORTFÓLIO</span>
              <ChevronRight className="w-4 h-4 stroke-[3]" />
            </a>

            {/* Navigation Arrows */}
            <div className="flex items-center gap-2 pt-2">
              <button
                onClick={() => handleScroll('left')}
                className="w-10 h-10 rounded-full border border-[#22c55e]/30 bg-[#0d1c14] hover:bg-[#22c55e] text-slate-300 hover:text-black flex items-center justify-center transition-colors shadow-md cursor-pointer"
                aria-label="Projeto anterior"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>
              <button
                onClick={() => handleScroll('right')}
                className="w-10 h-10 rounded-full border border-[#22c55e]/30 bg-[#0d1c14] hover:bg-[#22c55e] text-slate-300 hover:text-black flex items-center justify-center transition-colors shadow-md cursor-pointer"
                aria-label="Próximo projeto"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>

        {/* Category Filters */}
        <div className="flex items-center gap-2 overflow-x-auto pb-4 mb-8 scrollbar-none">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-4 py-2 rounded-full text-xs sm:text-sm font-bold whitespace-nowrap transition-all cursor-pointer ${
                selectedCategory === cat.id
                  ? 'bg-[#22c55e] text-black shadow-[0_0_15px_rgba(34,197,94,0.4)]'
                  : 'bg-[#102319]/80 text-slate-300 border border-[#22c55e]/20 hover:border-[#22c55e]/50 hover:text-white'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Carousel Showcase Container matching image.png */}
        <div
          id="portfolio-grid"
          ref={scrollRef}
          className="flex gap-6 overflow-x-auto pb-6 pt-2 snap-x snap-mandatory scrollbar-none"
        >
          {filteredProjects.map((project, index) => {
            const projectWhatsAppUrl = getWhatsAppUrl(
              phoneRaw,
              `Olá Jeferson! Vi o site "${project.title}" no seu portfólio e quero um projeto parecido para o meu negócio.`
            );

            return (
              <div
                key={project.id}
                className="w-[280px] sm:w-[320px] shrink-0 snap-start bg-[#0b1711] rounded-2xl overflow-hidden border border-[#22c55e]/30 hover:border-[#22c55e] transition-all duration-300 shadow-xl hover:shadow-[0_12px_35px_rgba(34,197,94,0.2)] flex flex-col group"
              >
                {/* Project Image Banner */}
                <div className="relative aspect-[16/10] w-full overflow-hidden bg-black">
                  <Image
                    src={project.image}
                    alt={project.title}
                    fill
                    className="object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  {/* Category Pill on image */}
                  <div className="absolute top-3 left-3 z-10">
                    <span className="bg-black/70 backdrop-blur-md text-[#4ade80] border border-[#22c55e]/40 text-[10px] font-bold px-2.5 py-1 rounded-full uppercase tracking-wider">
                      {project.categoryLabel}
                    </span>
                  </div>

                  {/* Hover Overlay with Action Buttons */}
                  <div className="absolute inset-0 bg-black/75 opacity-0 group-hover:opacity-100 transition-opacity duration-200 flex flex-col items-center justify-center gap-2 p-4">
                    <a
                      href={project.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      onClick={() => trackLeadClick('portfolio_open_site_direct', project.title)}
                      className="w-full flex items-center justify-center gap-1.5 bg-[#22c55e] hover:bg-[#20b857] text-black font-extrabold text-xs py-2 px-3 rounded-xl shadow-lg transition transform hover:scale-102"
                    >
                      <span>Abrir Site Real</span>
                      <ArrowUpRight className="w-3.5 h-3.5 stroke-[3]" />
                    </a>

                    <button
                      onClick={() => setActiveProjectModal(project)}
                      className="w-full flex items-center justify-center gap-1.5 bg-white/10 hover:bg-white/20 text-white font-semibold text-xs py-2 px-3 rounded-xl border border-white/20 transition cursor-pointer"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>Ver Detalhes</span>
                    </button>
                  </div>
                </div>

                {/* Card Bottom: White/Clean Container exactly as shown in image.png */}
                <div className="p-4 bg-white text-slate-900 flex-1 flex flex-col justify-between">
                  <div>
                    <h3 className="font-black text-base sm:text-lg text-slate-900 tracking-tight leading-snug">
                      {project.title}
                    </h3>
                    <p className="text-xs font-semibold text-slate-600 mt-0.5">
                      {project.subtitle}
                    </p>
                  </div>

                  {/* Quick Bottom Bar with Links */}
                  <div className="pt-3 mt-3 border-t border-slate-200 flex items-center justify-between">
                    <a
                      href={project.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      onClick={() => trackLeadClick('portfolio_card_link', project.title)}
                      className="inline-flex items-center gap-1 text-xs font-bold text-[#16a34a] hover:text-[#15803d] hover:underline"
                    >
                      <span>Visitar Site</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>

                    <a
                      href={projectWhatsAppUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      onClick={() => trackLeadClick('portfolio_card_whatsapp', project.title)}
                      title="Pedir orçamento deste modelo"
                      className="p-1.5 rounded-lg bg-[#22c55e]/15 text-[#15803d] hover:bg-[#22c55e] hover:text-black transition"
                    >
                      <MessageCircle className="w-4 h-4" />
                    </a>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Carousel Pagination Dots */}
        <div className="flex items-center justify-center gap-2 mt-8">
          {filteredProjects.map((_, dotIdx) => (
            <button
              key={dotIdx}
              onClick={() => {
                if (scrollRef.current) {
                  scrollRef.current.scrollTo({
                    left: dotIdx * 320,
                    behavior: 'smooth',
                  });
                  setCurrentIndex(dotIdx);
                }
              }}
              className={`h-2 rounded-full transition-all cursor-pointer ${
                currentIndex === dotIdx
                  ? 'w-8 bg-[#22c55e]'
                  : 'w-2 bg-[#22c55e]/30 hover:bg-[#22c55e]/60'
              }`}
              aria-label={`Ir para slide ${dotIdx + 1}`}
            />
          ))}
        </div>

        {/* Notice for clients and live URLs */}
        <div className="mt-12 p-4 sm:p-5 rounded-2xl bg-[#0e2117]/80 border border-[#22c55e]/25 text-center flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3 text-left">
            <div className="w-10 h-10 rounded-full bg-[#163826] border border-[#22c55e]/40 flex items-center justify-center text-[#22c55e] shrink-0">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <span className="text-sm font-bold text-white block">
                Quer um site exclusivo como esses para a sua empresa?
              </span>
              <span className="text-xs text-slate-300">
                Criamos o design, organizamos suas fotos e entregamos tudo pronto para vender!
              </span>
            </div>
          </div>

          <a
            href={getWhatsAppUrl(
              phoneRaw,
              'Olá Jeferson! Vi seus projetos e quero solicitar um orçamento personalizado para o meu negócio.'
            )}
            target="_blank"
            rel="noopener noreferrer"
            onClick={() => trackLeadClick('portfolio_bottom_custom_cta')}
            className="shrink-0 bg-[#22c55e] hover:bg-[#20b857] text-black font-extrabold text-xs sm:text-sm px-5 py-2.5 rounded-xl shadow-md transition"
          >
            Fazer Orçamento no WhatsApp
          </a>
        </div>
      </div>

      {/* Project Details Modal */}
      <ProjectModal
        project={activeProjectModal}
        phoneRaw={phoneRaw}
        phoneFormatted={phoneFormatted}
        onClose={() => setActiveProjectModal(null)}
      />
    </section>
  );
}
