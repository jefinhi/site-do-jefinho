'use client';

import Image from 'next/image';
import { QRCodeCard } from './QRCodeCard';
import {
  Clock,
  Settings,
  CheckCircle2,
  MessageCircle,
  PhoneCall,
  Sparkles,
  Zap,
} from 'lucide-react';
import { getWhatsAppUrl, trackLeadClick } from '@/lib/whatsapp-utils';

interface ContactCTAProps {
  phoneRaw: string;
  phoneFormatted: string;
}

export function ContactCTA({ phoneRaw, phoneFormatted }: ContactCTAProps) {
  const whatsappUrl = getWhatsAppUrl(
    phoneRaw,
    'Olá Jeferson! Gostaria de conversar sobre a criação do meu site e tirar meu projeto do papel.'
  );

  return (
    <section
      id="contato"
      className="relative py-20 sm:py-28 bg-gradient-to-b from-[#08120c] via-[#0b1c14] to-[#060c09] overflow-hidden"
    >
      {/* Background ambient lighting */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[900px] h-[500px] bg-[#22c55e]/15 blur-[180px] rounded-full pointer-events-none" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-[#09160f]/90 border-2 border-[#22c55e]/40 rounded-3xl p-6 sm:p-10 lg:p-12 shadow-[0_0_60px_rgba(34,197,94,0.18)] backdrop-blur-xl">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
            {/* Left/Center Column: Main Message & CTA */}
            <div className="lg:col-span-7 flex flex-col items-start">
              <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#163323] border border-[#22c55e]/40 text-[#4ade80] text-xs font-semibold mb-4">
                <Zap className="w-3.5 h-3.5 text-[#22c55e]" />
                <span>ATENDIMENTO DIRETO VIA WHATSAPP</span>
              </div>

              <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black text-white tracking-tight leading-tight mb-4">
                Vamos tirar seu <span className="text-[#22c55e]">projeto do papel?</span>
              </h2>

              <p className="text-base sm:text-lg text-slate-300 leading-relaxed max-w-xl mb-8">
                Entre em contato agora e peça um orçamento sem compromisso. Respondemos rápido para tirar todas as suas dúvidas.
              </p>

              {/* Big CTA Button */}
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => trackLeadClick('cta_fale_agora_whatsapp')}
                className="w-full sm:w-auto flex items-center justify-center gap-4 bg-[#22c55e] hover:bg-[#20b857] text-black px-8 py-4 sm:py-5 rounded-2xl shadow-[0_0_30px_rgba(34,197,94,0.5)] transition-all transform hover:scale-[1.02] active:scale-98 cursor-pointer mb-8"
              >
                <div className="w-10 h-10 bg-black text-[#22c55e] rounded-full flex items-center justify-center shrink-0">
                  <MessageCircle className="w-6 h-6 fill-[#22c55e]" />
                </div>
                <div className="flex flex-col text-left">
                  <span className="text-base sm:text-lg font-black tracking-tight leading-tight">
                    FALE AGORA NO WHATSAPP
                  </span>
                  <span className="text-xs font-bold text-black/80">
                    É rápido, fácil e sem compromisso!
                  </span>
                </div>
              </a>

              {/* 3 Value Pillars */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 w-full pt-4 border-t border-slate-800/80">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-[#163323] border border-[#22c55e]/30 flex items-center justify-center text-[#22c55e] shrink-0">
                    <Clock className="w-4 h-4" />
                  </div>
                  <span className="text-xs font-semibold text-slate-200">
                    Atendimento rápido
                  </span>
                </div>

                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-[#163323] border border-[#22c55e]/30 flex items-center justify-center text-[#22c55e] shrink-0">
                    <Settings className="w-4 h-4" />
                  </div>
                  <span className="text-xs font-semibold text-slate-200">
                    Suporte após a entrega
                  </span>
                </div>

                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-[#163323] border border-[#22c55e]/30 flex items-center justify-center text-[#22c55e] shrink-0">
                    <CheckCircle2 className="w-4 h-4 text-[#22c55e]" />
                  </div>
                  <span className="text-xs font-semibold text-slate-200">
                    Seu site no ar em pouco tempo
                  </span>
                </div>
              </div>
            </div>

            {/* Right Column: Scannable QR Code Component */}
            <div className="lg:col-span-5 flex justify-center lg:justify-end w-full">
              <QRCodeCard
                phoneRaw={phoneRaw}
                phoneFormatted={phoneFormatted}
                variant="footer"
                label="Aponte a câmera e fale comigo!"
                sublabel="Aponte a câmera do seu celular para abrir o WhatsApp"
                showDownload={true}
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
