'use client';

import { useState, useEffect } from 'react';
import { Navbar } from '@/components/Navbar';
import { Hero } from '@/components/Hero';
import { Services } from '@/components/Services';
import { Portfolio } from '@/components/Portfolio';
import { Testimonials } from '@/components/Testimonials';
import { ContactCTA } from '@/components/ContactCTA';
import { Footer } from '@/components/Footer';
import { FloatingWhatsApp } from '@/components/FloatingWhatsApp';
import { AdminDashboard } from '@/components/AdminDashboard';
import { ReviewModal } from '@/components/ReviewModal';
import {
  INITIAL_PROJECTS,
  INITIAL_CONFIG,
  TESTIMONIALS_DATA,
  Project,
  SiteConfig,
  Testimonial,
} from '@/lib/portfolio-data';

const STORAGE_PROJECTS_KEY = 'jr_portfolio_custom_projects';
const STORAGE_CONFIG_KEY = 'jr_portfolio_site_config';
const STORAGE_TESTIMONIALS_KEY = 'jr_portfolio_testimonials';

export default function HomePage() {
  const [projects, setProjects] = useState<Project[]>(() => {
    if (typeof window !== 'undefined') {
      try {
        const savedProjects = localStorage.getItem(STORAGE_PROJECTS_KEY);
        if (savedProjects) return JSON.parse(savedProjects);
      } catch {}
    }
    return INITIAL_PROJECTS;
  });

  const [siteConfig, setSiteConfig] = useState<SiteConfig>(() => {
    if (typeof window !== 'undefined') {
      try {
        const savedConfig = localStorage.getItem(STORAGE_CONFIG_KEY);
        if (savedConfig) return JSON.parse(savedConfig);
      } catch {}
    }
    return INITIAL_CONFIG;
  });

  const [testimonials, setTestimonials] = useState<Testimonial[]>(() => {
    if (typeof window !== 'undefined') {
      try {
        const savedTestimonials = localStorage.getItem(STORAGE_TESTIMONIALS_KEY);
        if (savedTestimonials) return JSON.parse(savedTestimonials);
      } catch {}
    }
    return TESTIMONIALS_DATA;
  });

  const [adminOpen, setAdminOpen] = useState(false);
  const [reviewModalOpen, setReviewModalOpen] = useState(false);

  const handleUpdateProjects = (updated: Project[]) => {
    setProjects(updated);
    try {
      localStorage.setItem(STORAGE_PROJECTS_KEY, JSON.stringify(updated));
    } catch (e) {
      console.warn('Error persisting projects:', e);
    }
  };

  const handleUpdateConfig = (updated: SiteConfig) => {
    setSiteConfig(updated);
    try {
      localStorage.setItem(STORAGE_CONFIG_KEY, JSON.stringify(updated));
    } catch (e) {
      console.warn('Error persisting config:', e);
    }
  };

  const handleUpdateTestimonials = (updated: Testimonial[]) => {
    setTestimonials(updated);
    try {
      localStorage.setItem(STORAGE_TESTIMONIALS_KEY, JSON.stringify(updated));
    } catch (e) {
      console.warn('Error persisting testimonials:', e);
    }
  };

  const handleAddTestimonial = (newReview: Testimonial) => {
    const updated = [newReview, ...testimonials];
    handleUpdateTestimonials(updated);
  };

  const handleLikeTestimonial = (id: string) => {
    const updated = testimonials.map((t) => {
      if (t.id === id) {
        return { ...t, likes: (t.likes || 0) + 1 };
      }
      return t;
    });
    handleUpdateTestimonials(updated);
  };

  return (
    <div className="min-h-screen bg-[#070e0a] text-slate-100 flex flex-col font-sans selection:bg-[#22c55e] selection:text-black">
      {/* Navigation Bar */}
      <Navbar
        phoneRaw={siteConfig.phoneRaw}
        phoneFormatted={siteConfig.phoneFormatted}
        onOpenAdmin={() => setAdminOpen(true)}
        onOpenReviewModal={() => setReviewModalOpen(true)}
      />

      {/* Main Content Sections */}
      <main className="flex-1">
        {/* Hero Section */}
        <Hero
          phoneRaw={siteConfig.phoneRaw}
          phoneFormatted={siteConfig.phoneFormatted}
          projects={projects}
        />

        {/* Nossos Serviços Section */}
        <Services phoneRaw={siteConfig.phoneRaw} />

        {/* Projetos Que Geram Resultados (Portfólio) */}
        <Portfolio
          phoneRaw={siteConfig.phoneRaw}
          phoneFormatted={siteConfig.phoneFormatted}
          projects={projects}
        />

        {/* Clientes que Confiam e Aprovam (Depoimentos e Avaliações) */}
        <Testimonials
          testimonials={testimonials}
          onOpenReviewModal={() => setReviewModalOpen(true)}
          onLikeTestimonial={handleLikeTestimonial}
        />

        {/* Vamos Tirar Seu Projeto do Papel? (CTA + QR Code) */}
        <ContactCTA
          phoneRaw={siteConfig.phoneRaw}
          phoneFormatted={siteConfig.phoneFormatted}
        />
      </main>

      {/* Footer */}
      <Footer
        phoneRaw={siteConfig.phoneRaw}
        phoneFormatted={siteConfig.phoneFormatted}
        onOpenAdmin={() => setAdminOpen(true)}
      />

      {/* Floating WhatsApp Action Button */}
      <FloatingWhatsApp
        phoneRaw={siteConfig.phoneRaw}
        phoneFormatted={siteConfig.phoneFormatted}
      />

      {/* Modal de Avaliação e Espaço para Comentários de Clientes */}
      <ReviewModal
        isOpen={reviewModalOpen}
        onClose={() => setReviewModalOpen(false)}
        onSubmit={handleAddTestimonial}
        siteConfig={siteConfig}
      />

      {/* Centralized Admin Dashboard for Jeferson Ribeiro */}
      <AdminDashboard
        isOpen={adminOpen}
        onClose={() => setAdminOpen(false)}
        projects={projects}
        onUpdateProjects={handleUpdateProjects}
        siteConfig={siteConfig}
        onUpdateConfig={handleUpdateConfig}
        testimonials={testimonials}
        onUpdateTestimonials={handleUpdateTestimonials}
      />
    </div>
  );
}
