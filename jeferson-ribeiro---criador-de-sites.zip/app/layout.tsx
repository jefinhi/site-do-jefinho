import type {Metadata} from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Jeferson Ribeiro - Criador de Sites Profissionais',
  description: 'Sites modernos, rápidos e responsivos para valorizar seu negócio e gerar resultados com atendimento direto via WhatsApp (22) 98172-8574.',
  openGraph: {
    title: 'Jeferson Ribeiro - Criador de Sites | Portfólio Profissional',
    description: 'Mais que um site, é o seu negócio no digital! Sites modernos, rápidos e responsivos para valorizar seu negócio.',
    type: 'website',
    locale: 'pt_BR',
    siteName: 'Jeferson Ribeiro - Criador de Sites',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Jeferson Ribeiro - Criador de Sites',
    description: 'Sites modernos, rápidos e responsivos para valorizar seu negócio e gerar resultados.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="pt-BR" className="scroll-smooth">
      <body suppressHydrationWarning className="bg-[#0b100e] text-slate-100 antialiased selection:bg-[#22c55e] selection:text-black">
        {children}
      </body>
    </html>
  );
}
